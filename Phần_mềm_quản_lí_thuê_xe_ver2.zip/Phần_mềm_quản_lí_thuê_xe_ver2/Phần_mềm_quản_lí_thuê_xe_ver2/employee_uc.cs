﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;
using static System.Windows.Forms.AxHost;

namespace Phần_mềm_quản_lí_thuê_xe_ver2
{
    public partial class employee_uc : UserControl
    {
        DataTable data_table_bang_nv = new DataTable();
        string cmnd, hoten, sdt, email, gioitinh, diachi, ngaysinh;
        public employee_uc()
        {
            InitializeComponent();
            btn_nam.CheckedChanged += RadioButton_CheckedChanged;
            btn_nu.CheckedChanged += RadioButton_CheckedChanged;
            data_table_bang_nv.Columns.Add("Số CMND Nhân Viên", typeof(string));
            data_table_bang_nv.Columns.Add("Họ Tên Nhân Viên", typeof(string));
            data_table_bang_nv.Columns.Add("Số Điện Thoại", typeof(string));
            data_table_bang_nv.Columns.Add("Email Nhân Viên", typeof(string));
            data_table_bang_nv.Columns.Add("Giới Tính", typeof(string));
            data_table_bang_nv.Columns.Add("Địa chỉ", typeof(string));
            data_table_bang_nv.Columns.Add("Ngày Sinh", typeof(string));
        }


        private void employee_uc_Load(object sender, EventArgs e)
        {
            load_bang_nv();
        }
        private void load_bang_nv()
        {
            data_table_bang_nv.Clear();
            using (SqlCommand query = new SqlCommand())
            {
                query.CommandText = @"SELECT * FROM Nhan_Vien";
                query.Connection = control_dash_board.pipe_connect;
                SqlDataReader reader = query.ExecuteReader();
                while (reader.Read())
                {
                    data_table_bang_nv.Rows.Add(reader[0].ToString(), reader[1].ToString(), reader[2].ToString(), reader[3].ToString(), reader[4].ToString(), reader[5].ToString(), DateTime.Parse(reader[6].ToString()).ToString("dd/MM/yyyy"));
                }
                bang_nhan_vien.DataSource = data_table_bang_nv;
            }
            tb_cmnd.Text = "";
            tb_hoten.Text = "";
            tb_sdt.Text = "";
            tb_email.Text = "";
            tb_diachi.Text = "";
            btn_nam.Checked = false;
            btn_nu.Checked = false;
        }

        private void RadioButton_CheckedChanged(object sender, EventArgs e)
        {
            // Kiểm tra xem RadioButton nào đã được chọn và lấy giá trị tương ứng
            RadioButton selectedRadio = (RadioButton)sender;
            if (selectedRadio.Text == "Nam")
            {
                gioitinh = "Nam";
            }
            else
            {
                gioitinh = "Nữ";
            }
        }


        private void them_nv_button_Click(object sender, EventArgs e)
        {
            try
            {
                cmnd = tb_cmnd.Text;
                hoten = tb_hoten.Text;
                sdt = tb_sdt.Text;
                email = tb_email.Text;
                diachi = tb_diachi.Text;

                // Thay đổi kiểu dữ liệu của ngaysinh từ string sang DateTime
                DateTime ngaysinhDateTime = tb_ngaysinh.Value;

                // Format lại ngày tháng năm thành chuỗi "yyyy-MM-dd" để phù hợp với định dạng ngày của SQL Server
                ngaysinh = ngaysinhDateTime.ToString("yyyy-MM-dd");

                string insertQuery = @"INSERT INTO Nhan_Vien (cccd_nv, ho_ten, sdt, email, gioi_tinh, que_quan, ngay_sinh) 
                       VALUES (@cmnd, @hoten, @sdt, @email, @gioitinh, @diachi, @ngaysinh)";

                SqlCommand command = new SqlCommand(insertQuery, control_dash_board.pipe_connect);
                command.Parameters.AddWithValue("@cmnd", cmnd);
                command.Parameters.AddWithValue("@hoten", hoten);
                command.Parameters.AddWithValue("@sdt", sdt);
                command.Parameters.AddWithValue("@email", email);
                command.Parameters.AddWithValue("@gioitinh", gioitinh);
                command.Parameters.AddWithValue("@diachi", diachi);
                command.Parameters.AddWithValue("@ngaysinh", ngaysinh);

                command.ExecuteNonQuery();

                load_bang_nv();
            }
            catch
            {
                MessageBox.Show("Chưa đủ điều kiện để thêm nhân viên");
            }


        }
        private void button_sua_nv_Click(object sender, EventArgs e)
        {
            // Kiểm tra nếu không có hàng nào được chọn
            if (bang_nhan_vien.SelectedRows.Count == 0)
            {
                MessageBox.Show("Vui lòng chọn một hàng để sửa!");
                return;
            }
            try
            {
                // Lấy thông tin đã chỉnh sửa
                cmnd = tb_cmnd.Text.Trim();
                hoten = tb_hoten.Text;
                sdt = tb_sdt.Text;
                email = tb_email.Text;
                diachi = tb_diachi.Text;
                // Thay đổi kiểu dữ liệu của ngaysinh từ string sang DateTime
                DateTime ngaysinhDateTime = tb_ngaysinh.Value;

                // Format lại ngày tháng năm thành chuỗi "yyyy-MM-dd" để phù hợp với định dạng ngày của SQL Server
                ngaysinh = ngaysinhDateTime.ToString("yyyy-MM-dd");
                // Thực hiện truy vấn cập nhật thông tin
                // (Đảm bảo control_dash_board và pipe_connect đã được khởi tạo trước đó)
                // control.ket_noi();
                string updateQuery = @"UPDATE Nhan_Vien SET ho_ten = @hoten, sdt = @sdt, email = @email, gioi_tinh = @gioitinh, que_quan = @diachi, ngay_sinh = @ngaysinh 
                                       WHERE cccd_nv = @cmnd";
                SqlCommand command = new SqlCommand(updateQuery, control_dash_board.pipe_connect);
                command.Parameters.AddWithValue("@cmnd", cmnd);
                command.Parameters.AddWithValue("@hoten", hoten);
                command.Parameters.AddWithValue("@sdt", sdt);
                command.Parameters.AddWithValue("@email", email);
                command.Parameters.AddWithValue("@gioitinh", gioitinh);
                command.Parameters.AddWithValue("@diachi", diachi);
                command.Parameters.AddWithValue("@ngaysinh", ngaysinh);
                

                command.ExecuteNonQuery();

                // Hiển thị lại danh sách sau khi cập nhật
                load_bang_nv();

                // Xóa dữ liệu trên các control và vô hiệu hóa nút sửa

                button_sua_nv.Enabled = false;

            }
            catch
            {
                MessageBox.Show("Cập nhật dữ liệu không thành công");
            }

            
            
        }
        private void button_xoa_nv_Click(object sender, EventArgs e)
        {
            // Kiểm tra nếu không có hàng nào được chọn
            try
            {
                if (bang_nhan_vien.SelectedRows.Count == 0)
                {
                    MessageBox.Show("Vui lòng chọn một hàng để xóa!");
                    return;
                }

                string selectedId = bang_nhan_vien.SelectedRows[0].Cells["Số CMND Nhân Viên"].Value.ToString();
                // control.ket_noi();
                string deleteQuery = "DELETE FROM Nhan_Vien WHERE cccd_nv = @cmnd";
                SqlCommand command = new SqlCommand(deleteQuery, control_dash_board.pipe_connect);
                command.Parameters.AddWithValue("@cmnd", selectedId);
                // Thực thi truy vấn xóa
                command.ExecuteNonQuery();

                load_bang_nv();
                MessageBox.Show("Xóa dữ liệu thành công!");

            }
            catch
            {
                MessageBox.Show("Xóa dữ liệu không thành công");
            }
        }

        private void bang_nhan_vien_Click(object sender, EventArgs e)
        {
            // Kiểm tra xem có hàng nào được chọn hay không
            if (bang_nhan_vien.SelectedCells[0].Value != null)
            {
                try
                {
                    // Lấy dữ liệu từ hàng được chọn
                    var selectedRow = bang_nhan_vien.SelectedRows[0];
                    tb_cmnd.Text = selectedRow.Cells["Số CMND Nhân Viên"].Value.ToString().Trim();
                    tb_hoten.Text = selectedRow.Cells["Họ Tên Nhân Viên"].Value.ToString();
                    tb_sdt.Text = selectedRow.Cells["Số Điện Thoại"].Value.ToString();
                    tb_email.Text = selectedRow.Cells["Email Nhân Viên"].Value.ToString();
                    if (selectedRow.Cells["Giới Tính"].Value.ToString() == "Nam")
                        btn_nam.Checked = true;
                    else
                    {
                        btn_nu.Checked = true;
                    }

                    tb_diachi.Text = selectedRow.Cells["Địa chỉ"].Value.ToString();
                    string s = selectedRow.Cells["Ngày Sinh"].Value.ToString();
                    string[] parts = s.Split('/');
                    int day = int.Parse(parts[0]);
                    int month = int.Parse(parts[1]);
                    int year = int.Parse(parts[2]);

                    // Tạo đối tượng DateTime từ ngày, tháng, năm
                    DateTime date = new DateTime(year, month, day);

                    // Định dạng lại chuỗi ngày tháng theo định dạng mới
                    string newDateFormat = date.ToString("MM/dd/yyyy");
                    tb_ngaysinh.Text = newDateFormat;
                    // Kích hoạt nút sửa
                    button_sua_nv.Enabled = true;

                }
                catch
                {
                    MessageBox.Show("Dữ liệu chọn không hợp lệ!");
                }
            }
        }
        
    }
}
