﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ComponentFactory.Krypton.Toolkit;
using Guna.UI2.WinForms;
using System.Threading;
using System.Data.SqlClient;

namespace Phần_mềm_quản_lí_thuê_xe_ver2
{
    public partial class dash_board : KryptonForm
    {
        public Dictionary<string, bool> _buttonState = new Dictionary<string, bool>();
        control_dash_board control = new control_dash_board();

        public dash_board()
        {
            InitializeComponent();
            Control.CheckForIllegalCrossThreadCalls = false;
            _buttonState.Add("home_button", true);
            _buttonState.Add("customers_button", false);
            _buttonState.Add("vehicles_button", false);
            _buttonState.Add("suppliers_button", false);
            _buttonState.Add("employee_button", false);
            _buttonState.Add("reports_button", false);

        }
        private void cap_nhat_button_state(string buttonname)
        {
            foreach(string button in _buttonState.Keys.ToArray())
            {
                _buttonState[button] = false;
            }
            _buttonState[buttonname] = true;
        }

        private void dash_board_Load(object sender, EventArgs e)
        {
            control.ket_noi();
            using (SqlCommand query = new SqlCommand())
            {
                query.CommandText = $@"SELECT so_cccd FROM Tai_khoan
                                       WHERE ten_dang_nhap = '{control_dash_board.username_session}'";
                query.Connection = control_dash_board.pipe_connect;
                control_dash_board.cccd_session = query.ExecuteScalar().ToString();
                query.CommandText = $@"SELECT ho_ten FROM Nhan_Vien
                                       WHERE cccd_nv = '{control_dash_board.cccd_session}'";
                control_dash_board.username_session = query.ExecuteScalar().ToString();
            }
            load_usercontrol(new home());
        }
        private void dash_board_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void load_usercontrol(UserControl userControl)
        {

            this.Invoke((MethodInvoker)delegate
            {
                userControl.Dock = DockStyle.Fill;
                main_center.Controls.Clear();
                main_center.Controls.Add(userControl);
                userControl.BringToFront();
            });
        }



        private void home_button_Click(object sender, EventArgs e)
        {
            string buttonname = ((Guna2Button)sender).Name;
            if (_buttonState[buttonname] == false)
            {
               
               // moveImageBox(sender);
                load_usercontrol(new home());
                Console.WriteLine($"{buttonname}");
                cap_nhat_button_state(buttonname);
                
            }
        }

        private void customers_button_Click(object sender, EventArgs e)
        {
            string buttonname = ((Guna2Button)sender).Name;
            if (_buttonState[buttonname] == false)
            {
               
                //moveImageBox(sender);
                load_usercontrol(new customer_uc());
                Console.WriteLine($"{buttonname}");
                cap_nhat_button_state(buttonname);
            }
        }

        private void vehicles_button_Click(object sender, EventArgs e)
        {
            string buttonname = ((Guna2Button)sender).Name;
            if (_buttonState[buttonname] == false)
            {
                //moveImageBox(sender);
                load_usercontrol(new vehicles_uc());
                Console.WriteLine($"{buttonname}");
                cap_nhat_button_state(buttonname);
            }
        }

        private void suppliers_button_Click(object sender, EventArgs e)
        {
            string buttonname = ((Guna2Button)sender).Name;
            if (_buttonState[buttonname] == false)
            {
                load_usercontrol(new suppliers_uc());
                Console.WriteLine($"{buttonname}");
                cap_nhat_button_state(buttonname);
            }
        }


        private void Employee_button_Click(object sender, EventArgs e)
        {
            string buttonname = (((Guna2Button)sender).Name);
            if (_buttonState[buttonname] == false)
            {
                load_usercontrol(new employee_uc());
                Console.WriteLine(buttonname);
                cap_nhat_button_state(buttonname);
            }
        }

        private void reports_button_Click(object sender, EventArgs e)
        {
            string buttonname = ((Guna2Button)sender).Name;
            if (_buttonState[buttonname] == false)
            {
                load_usercontrol(new reports_uc());
                Console.WriteLine($"{buttonname}");
                cap_nhat_button_state(buttonname);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Dispose();
            Login_Register_Form loginform = new Login_Register_Form();
                loginform.Show();
        }

      

        private void moveImageBox(object sender)
        {
            new Thread(
                () =>
                {
                    Guna2Button button = (Guna2Button)sender;
                    imgslide.Location = new Point(button.Location.X + 49, button.Location.Y - 19);
                    imgslide.SendToBack();

                }
                )
            { IsBackground = true }.Start();

            
        }
        private void button_CheckedChanged(object sender, EventArgs e)
        {
            moveImageBox(sender);
        }
    }
}
