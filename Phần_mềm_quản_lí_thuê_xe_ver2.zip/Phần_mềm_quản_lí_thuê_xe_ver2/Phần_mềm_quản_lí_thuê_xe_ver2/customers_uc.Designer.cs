﻿namespace Phần_mềm_quản_lí_thuê_xe_ver2
{
    partial class customer_uc
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.bang_khach = new System.Windows.Forms.DataGridView();
            this.guna2ShadowPanel1 = new Guna.UI2.WinForms.Guna2ShadowPanel();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.tb_sdt = new Guna.UI2.WinForms.Guna2TextBox();
            this.tb_hoten = new Guna.UI2.WinForms.Guna2TextBox();
            this.tb_cccd = new Guna.UI2.WinForms.Guna2TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.tb_email = new Guna.UI2.WinForms.Guna2TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.btn_nu = new System.Windows.Forms.RadioButton();
            this.btn_nam = new System.Windows.Forms.RadioButton();
            this.label4 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.tb_ngaysinh = new System.Windows.Forms.DateTimePicker();
            this.tb_diachi = new Guna.UI2.WinForms.Guna2TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.xoa_khach_button = new Guna.UI2.WinForms.Guna2Button();
            this.sua_khach_button = new Guna.UI2.WinForms.Guna2Button();
            this.them_khach_button = new Guna.UI2.WinForms.Guna2Button();
            ((System.ComponentModel.ISupportInitialize)(this.bang_khach)).BeginInit();
            this.guna2ShadowPanel1.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.panel4.SuspendLayout();
            this.SuspendLayout();
            // 
            // bang_khach
            // 
            this.bang_khach.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.bang_khach.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.bang_khach.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.bang_khach.Location = new System.Drawing.Point(3, 2);
            this.bang_khach.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.bang_khach.Name = "bang_khach";
            this.bang_khach.ReadOnly = true;
            this.bang_khach.RowHeadersWidth = 51;
            this.bang_khach.RowTemplate.Height = 24;
            this.bang_khach.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.bang_khach.Size = new System.Drawing.Size(1151, 377);
            this.bang_khach.TabIndex = 0;
            this.bang_khach.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.bang_khach_CellClick);
            // 
            // guna2ShadowPanel1
            // 
            this.guna2ShadowPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2ShadowPanel1.BackColor = System.Drawing.Color.Transparent;
            this.guna2ShadowPanel1.Controls.Add(this.bang_khach);
            this.guna2ShadowPanel1.FillColor = System.Drawing.Color.White;
            this.guna2ShadowPanel1.Location = new System.Drawing.Point(3, 230);
            this.guna2ShadowPanel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2ShadowPanel1.Name = "guna2ShadowPanel1";
            this.guna2ShadowPanel1.ShadowColor = System.Drawing.Color.Black;
            this.guna2ShadowPanel1.ShadowStyle = Guna.UI2.WinForms.Guna2ShadowPanel.ShadowMode.Dropped;
            this.guna2ShadowPanel1.Size = new System.Drawing.Size(1156, 395);
            this.guna2ShadowPanel1.TabIndex = 1;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel1.Controls.Add(this.panel1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.panel2, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.panel3, 2, 0);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(3, 2);
            this.tableLayoutPanel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1151, 146);
            this.tableLayoutPanel1.TabIndex = 2;
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.Controls.Add(this.tb_sdt);
            this.panel1.Controls.Add(this.tb_hoten);
            this.panel1.Controls.Add(this.tb_cccd);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(3, 2);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(377, 142);
            this.panel1.TabIndex = 0;
            // 
            // tb_sdt
            // 
            this.tb_sdt.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tb_sdt.Animated = true;
            this.tb_sdt.AutoRoundedCorners = true;
            this.tb_sdt.BorderRadius = 18;
            this.tb_sdt.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.tb_sdt.DefaultText = "";
            this.tb_sdt.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.tb_sdt.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.tb_sdt.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tb_sdt.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tb_sdt.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tb_sdt.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.tb_sdt.ForeColor = System.Drawing.Color.Black;
            this.tb_sdt.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tb_sdt.Location = new System.Drawing.Point(103, 97);
            this.tb_sdt.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tb_sdt.Name = "tb_sdt";
            this.tb_sdt.PasswordChar = '\0';
            this.tb_sdt.PlaceholderText = "";
            this.tb_sdt.SelectedText = "";
            this.tb_sdt.Size = new System.Drawing.Size(268, 38);
            this.tb_sdt.TabIndex = 5;
            // 
            // tb_hoten
            // 
            this.tb_hoten.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tb_hoten.Animated = true;
            this.tb_hoten.AutoRoundedCorners = true;
            this.tb_hoten.BorderRadius = 18;
            this.tb_hoten.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.tb_hoten.DefaultText = "";
            this.tb_hoten.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.tb_hoten.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.tb_hoten.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tb_hoten.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tb_hoten.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tb_hoten.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.tb_hoten.ForeColor = System.Drawing.Color.Black;
            this.tb_hoten.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tb_hoten.Location = new System.Drawing.Point(103, 50);
            this.tb_hoten.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tb_hoten.Name = "tb_hoten";
            this.tb_hoten.PasswordChar = '\0';
            this.tb_hoten.PlaceholderText = "";
            this.tb_hoten.SelectedText = "";
            this.tb_hoten.Size = new System.Drawing.Size(268, 38);
            this.tb_hoten.TabIndex = 4;
            // 
            // tb_cccd
            // 
            this.tb_cccd.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tb_cccd.Animated = true;
            this.tb_cccd.AutoRoundedCorners = true;
            this.tb_cccd.BorderRadius = 18;
            this.tb_cccd.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.tb_cccd.DefaultText = "";
            this.tb_cccd.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.tb_cccd.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.tb_cccd.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tb_cccd.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tb_cccd.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tb_cccd.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.tb_cccd.ForeColor = System.Drawing.Color.Black;
            this.tb_cccd.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tb_cccd.Location = new System.Drawing.Point(103, 5);
            this.tb_cccd.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tb_cccd.Name = "tb_cccd";
            this.tb_cccd.PasswordChar = '\0';
            this.tb_cccd.PlaceholderText = "";
            this.tb_cccd.SelectedText = "";
            this.tb_cccd.Size = new System.Drawing.Size(268, 38);
            this.tb_cccd.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(11, 114);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(85, 16);
            this.label3.TabIndex = 2;
            this.label3.Text = "Số điện thoại";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 68);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(52, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "Họ Tên";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(67, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Số CMND";
            // 
            // panel2
            // 
            this.panel2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel2.Controls.Add(this.tb_email);
            this.panel2.Controls.Add(this.label6);
            this.panel2.Controls.Add(this.btn_nu);
            this.panel2.Controls.Add(this.btn_nam);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Location = new System.Drawing.Point(386, 2);
            this.panel2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(377, 142);
            this.panel2.TabIndex = 1;
            // 
            // tb_email
            // 
            this.tb_email.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tb_email.Animated = true;
            this.tb_email.AutoRoundedCorners = true;
            this.tb_email.BorderRadius = 18;
            this.tb_email.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.tb_email.DefaultText = "";
            this.tb_email.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.tb_email.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.tb_email.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tb_email.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tb_email.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tb_email.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.tb_email.ForeColor = System.Drawing.Color.Black;
            this.tb_email.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tb_email.Location = new System.Drawing.Point(80, 14);
            this.tb_email.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tb_email.Name = "tb_email";
            this.tb_email.PasswordChar = '\0';
            this.tb_email.PlaceholderText = "";
            this.tb_email.SelectedText = "";
            this.tb_email.Size = new System.Drawing.Size(268, 38);
            this.tb_email.TabIndex = 6;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(33, 90);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(54, 16);
            this.label6.TabIndex = 3;
            this.label6.Text = "Giới tính";
            // 
            // btn_nu
            // 
            this.btn_nu.AutoSize = true;
            this.btn_nu.Location = new System.Drawing.Point(216, 90);
            this.btn_nu.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_nu.Name = "btn_nu";
            this.btn_nu.Size = new System.Drawing.Size(45, 20);
            this.btn_nu.TabIndex = 2;
            this.btn_nu.TabStop = true;
            this.btn_nu.Text = "Nữ";
            this.btn_nu.UseVisualStyleBackColor = true;
            // 
            // btn_nam
            // 
            this.btn_nam.AutoSize = true;
            this.btn_nam.Location = new System.Drawing.Point(117, 90);
            this.btn_nam.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_nam.Name = "btn_nam";
            this.btn_nam.Size = new System.Drawing.Size(57, 20);
            this.btn_nam.TabIndex = 1;
            this.btn_nam.TabStop = true;
            this.btn_nam.Text = "Nam";
            this.btn_nam.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(33, 26);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(41, 16);
            this.label4.TabIndex = 0;
            this.label4.Text = "Email";
            // 
            // panel3
            // 
            this.panel3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel3.Controls.Add(this.tb_ngaysinh);
            this.panel3.Controls.Add(this.tb_diachi);
            this.panel3.Controls.Add(this.label7);
            this.panel3.Controls.Add(this.label5);
            this.panel3.Location = new System.Drawing.Point(769, 2);
            this.panel3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(379, 142);
            this.panel3.TabIndex = 2;
            // 
            // tb_ngaysinh
            // 
            this.tb_ngaysinh.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tb_ngaysinh.CustomFormat = "dd/MM/yyyy";
            this.tb_ngaysinh.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.tb_ngaysinh.Location = new System.Drawing.Point(109, 90);
            this.tb_ngaysinh.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tb_ngaysinh.Name = "tb_ngaysinh";
            this.tb_ngaysinh.Size = new System.Drawing.Size(232, 22);
            this.tb_ngaysinh.TabIndex = 7;
            // 
            // tb_diachi
            // 
            this.tb_diachi.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tb_diachi.Animated = true;
            this.tb_diachi.AutoRoundedCorners = true;
            this.tb_diachi.BorderRadius = 18;
            this.tb_diachi.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.tb_diachi.DefaultText = "";
            this.tb_diachi.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.tb_diachi.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.tb_diachi.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tb_diachi.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tb_diachi.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tb_diachi.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.tb_diachi.ForeColor = System.Drawing.Color.Black;
            this.tb_diachi.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tb_diachi.Location = new System.Drawing.Point(93, 14);
            this.tb_diachi.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tb_diachi.Name = "tb_diachi";
            this.tb_diachi.PasswordChar = '\0';
            this.tb_diachi.PlaceholderText = "";
            this.tb_diachi.SelectedText = "";
            this.tb_diachi.Size = new System.Drawing.Size(268, 38);
            this.tb_diachi.TabIndex = 6;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(25, 90);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(67, 16);
            this.label7.TabIndex = 1;
            this.label7.Text = "Ngày sinh";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(28, 25);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(47, 16);
            this.label5.TabIndex = 0;
            this.label5.Text = "Địa chỉ";
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel2.ColumnCount = 3;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 705F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Controls.Add(this.panel4, 1, 0);
            this.tableLayoutPanel2.Location = new System.Drawing.Point(5, 156);
            this.tableLayoutPanel2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 1;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(1147, 68);
            this.tableLayoutPanel2.TabIndex = 3;
            // 
            // panel4
            // 
            this.panel4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel4.Controls.Add(this.xoa_khach_button);
            this.panel4.Controls.Add(this.sua_khach_button);
            this.panel4.Controls.Add(this.them_khach_button);
            this.panel4.Location = new System.Drawing.Point(224, 2);
            this.panel4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(699, 62);
            this.panel4.TabIndex = 7;
            // 
            // xoa_khach_button
            // 
            this.xoa_khach_button.Animated = true;
            this.xoa_khach_button.AutoRoundedCorners = true;
            this.xoa_khach_button.BorderRadius = 22;
            this.xoa_khach_button.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.xoa_khach_button.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.xoa_khach_button.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.xoa_khach_button.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.xoa_khach_button.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.xoa_khach_button.ForeColor = System.Drawing.Color.White;
            this.xoa_khach_button.Location = new System.Drawing.Point(509, 7);
            this.xoa_khach_button.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.xoa_khach_button.Name = "xoa_khach_button";
            this.xoa_khach_button.Size = new System.Drawing.Size(180, 46);
            this.xoa_khach_button.TabIndex = 6;
            this.xoa_khach_button.Text = "Xóa thông tin khách";
            this.xoa_khach_button.Click += new System.EventHandler(this.xoa_khach_button_Click);
            // 
            // sua_khach_button
            // 
            this.sua_khach_button.Animated = true;
            this.sua_khach_button.AutoRoundedCorners = true;
            this.sua_khach_button.BorderRadius = 22;
            this.sua_khach_button.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.sua_khach_button.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.sua_khach_button.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.sua_khach_button.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.sua_khach_button.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.sua_khach_button.ForeColor = System.Drawing.Color.White;
            this.sua_khach_button.Location = new System.Drawing.Point(259, 7);
            this.sua_khach_button.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.sua_khach_button.Name = "sua_khach_button";
            this.sua_khach_button.Size = new System.Drawing.Size(180, 46);
            this.sua_khach_button.TabIndex = 5;
            this.sua_khach_button.Text = "Sửa thông tin khách";
            this.sua_khach_button.Click += new System.EventHandler(this.sua_khach_button_Click);
            // 
            // them_khach_button
            // 
            this.them_khach_button.Animated = true;
            this.them_khach_button.AutoRoundedCorners = true;
            this.them_khach_button.BorderRadius = 22;
            this.them_khach_button.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.them_khach_button.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.them_khach_button.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.them_khach_button.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.them_khach_button.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.them_khach_button.ForeColor = System.Drawing.Color.White;
            this.them_khach_button.Location = new System.Drawing.Point(9, 7);
            this.them_khach_button.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.them_khach_button.Name = "them_khach_button";
            this.them_khach_button.Size = new System.Drawing.Size(180, 46);
            this.them_khach_button.TabIndex = 4;
            this.them_khach_button.Text = "Thêm";
            this.them_khach_button.Click += new System.EventHandler(this.them_khach_button_Click);
            // 
            // customer_uc
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.tableLayoutPanel2);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Controls.Add(this.guna2ShadowPanel1);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "customer_uc";
            this.Size = new System.Drawing.Size(1160, 628);
            this.Load += new System.EventHandler(this.customer_uc_Load);
            ((System.ComponentModel.ISupportInitialize)(this.bang_khach)).EndInit();
            this.guna2ShadowPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView bang_khach;
        private Guna.UI2.WinForms.Guna2ShadowPanel guna2ShadowPanel1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.RadioButton btn_nam;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label5;
        private Guna.UI2.WinForms.Guna2TextBox tb_cccd;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.RadioButton btn_nu;
        private Guna.UI2.WinForms.Guna2TextBox tb_sdt;
        private Guna.UI2.WinForms.Guna2TextBox tb_hoten;
        private Guna.UI2.WinForms.Guna2TextBox tb_email;
        private System.Windows.Forms.DateTimePicker tb_ngaysinh;
        private Guna.UI2.WinForms.Guna2TextBox tb_diachi;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private Guna.UI2.WinForms.Guna2Button them_khach_button;
        private Guna.UI2.WinForms.Guna2Button sua_khach_button;
        private Guna.UI2.WinForms.Guna2Button xoa_khach_button;
        private System.Windows.Forms.Panel panel4;
    }
}
