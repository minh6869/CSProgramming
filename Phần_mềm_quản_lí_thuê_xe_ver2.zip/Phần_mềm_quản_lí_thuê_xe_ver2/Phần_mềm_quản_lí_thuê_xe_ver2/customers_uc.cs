﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Phần_mềm_quản_lí_thuê_xe_ver2
{
    public partial class customer_uc : UserControl
    {
        string cccd, hoten, sdt, email, gioitinh, diachi, ngaysinh;
        DataTable data_table_bang_khach = new DataTable();
        public customer_uc()
        {
            InitializeComponent();
            
        }


        private void customer_uc_Load(object sender, EventArgs e)
        {
            data_table_bang_khach.Columns.Add("Số CMND Khách", typeof(string));
            data_table_bang_khach.Columns.Add("Họ Tên Khách", typeof(string));
            data_table_bang_khach.Columns.Add("Số Điện Thoại", typeof(string));
            data_table_bang_khach.Columns.Add("Email Khách", typeof(string));
            data_table_bang_khach.Columns.Add("Giới Tính", typeof(string));
            data_table_bang_khach.Columns.Add("Địa chỉ", typeof(string));
            data_table_bang_khach.Columns.Add("Ngày Sinh", typeof(string));
            btn_nam.CheckedChanged += RadioButton_CheckedChanged;
            btn_nu.CheckedChanged += RadioButton_CheckedChanged;
            load_bang_khach();

        }
        private void RadioButton_CheckedChanged(object sender, EventArgs e)
        {
            // Kiểm tra xem RadioButton nào đã được chọn và lấy giá trị tương ứng
            RadioButton selectedRadio = (RadioButton)sender;
            if (selectedRadio.Text == "Nam")
            {
                gioitinh = "Nam";
            }
            else
            {
                gioitinh = "Nữ";
            }
        }
        private void load_bang_khach()
        {
            data_table_bang_khach.Clear();
            using (SqlCommand query = new SqlCommand())
            {
                query.CommandText = @"SELECT * FROM Khach_Hang";
                query.Connection = control_dash_board.pipe_connect;
                SqlDataReader reader = query.ExecuteReader();
                while (reader.Read())
                {
                    data_table_bang_khach.Rows.Add(reader[0].ToString(), reader[1].ToString(), reader[2].ToString(), reader[3].ToString(), reader[4].ToString(), reader[5].ToString(), DateTime.Parse(reader[6].ToString()).ToString("dd/MM/yyyy"));
                }
                reader.Close();
                bang_khach.DataSource = data_table_bang_khach;
            }
            tb_cccd.Text = "";
            tb_hoten.Text = "";
            tb_sdt.Text = "";
            tb_email.Text = "";
            tb_diachi.Text = "";
            btn_nam.Checked = false;
            btn_nu.Checked = false;
        }
        private void them_khach_button_Click(object sender, EventArgs e)
        {
            try
            {
                cccd = tb_cccd.Text;
                hoten = tb_hoten.Text;
                sdt = tb_sdt.Text;
                email = tb_email.Text;
                diachi = tb_diachi.Text;

                // Thay đổi kiểu dữ liệu của ngaysinh từ string sang DateTime
                DateTime ngaysinhDateTime = tb_ngaysinh.Value;

                // Format lại ngày tháng năm thành chuỗi "yyyy-MM-dd" để phù hợp với định dạng ngày của SQL Server
                ngaysinh = ngaysinhDateTime.ToString("yyyy-MM-dd");

                string insertQuery = @"INSERT INTO Khach_Hang (cccd_khach, ho_ten, sdt, email, gioi_tinh, que_quan, ngay_sinh) 
                       VALUES (@cccd, @hoten, @sdt, @email, @gioitinh, @diachi, @ngaysinh)";

                SqlCommand command = new SqlCommand(insertQuery, control_dash_board.pipe_connect);
                command.Parameters.AddWithValue("@cccd", cccd);
                command.Parameters.AddWithValue("@hoten", hoten);
                command.Parameters.AddWithValue("@sdt", sdt);
                command.Parameters.AddWithValue("@email", email);
                command.Parameters.AddWithValue("@gioitinh", gioitinh);
                command.Parameters.AddWithValue("@diachi", diachi);
                command.Parameters.AddWithValue("@ngaysinh", ngaysinh);

                command.ExecuteNonQuery();

                load_bang_khach();
            }
            catch
            {
                MessageBox.Show("Chưa đủ điều kiện để thêm nhân viên");
            }

        }
        private void sua_khach_button_Click(object sender, EventArgs e)
        {
            // Kiểm tra nếu không có hàng nào được chọn
            if (bang_khach.SelectedRows.Count == 0)
            {
                MessageBox.Show("Vui lòng chọn một hàng để sửa!");
                return;
            }


            // Lấy thông tin đã chỉnh sửa
            cccd = tb_cccd.Text.Trim();
            hoten = tb_hoten.Text;
            sdt = tb_sdt.Text;
            email = tb_email.Text;
            diachi = tb_diachi.Text;
            // Thay đổi kiểu dữ liệu của ngaysinh từ string sang DateTime
            DateTime ngaysinhDateTime = tb_ngaysinh.Value;

            // Format lại ngày tháng năm thành chuỗi "yyyy-MM-dd" để phù hợp với định dạng ngày của SQL Server
            ngaysinh = ngaysinhDateTime.ToString("yyyy-MM-dd");
            // Thực hiện truy vấn cập nhật thông tin
            // (Đảm bảo control_dash_board và pipe_connect đã được khởi tạo trước đó)
            // control.ket_noi();
            string updateQuery = @"UPDATE Khach_Hang SET ho_ten = @hoten, sdt = @sdt, email = @email, gioi_tinh = @gioitinh, que_quan = @diachi, ngay_sinh = @ngaysinh 
                                       WHERE cccd_khach = @cccd";
            SqlCommand command = new SqlCommand(updateQuery, control_dash_board.pipe_connect);
            command.Parameters.AddWithValue("@cccd", cccd);
            command.Parameters.AddWithValue("@hoten", hoten);
            command.Parameters.AddWithValue("@sdt", sdt);
            command.Parameters.AddWithValue("@email", email);
            command.Parameters.AddWithValue("@gioitinh", gioitinh);
            command.Parameters.AddWithValue("@diachi", diachi);
            command.Parameters.AddWithValue("@ngaysinh", ngaysinh);


            command.ExecuteNonQuery();

            // Hiển thị lại danh sách sau khi cập nhật
            load_bang_khach();

            // Xóa dữ liệu trên các control và vô hiệu hóa nút sửa

            sua_khach_button.Enabled = false;
            MessageBox.Show("Cập nhật dữ liệu khách thành công!");
        }
        private void xoa_khach_button_Click(object sender, EventArgs e)
        {
            // Kiểm tra nếu không có hàng nào được chọn
            try
            {
                if (bang_khach.SelectedRows.Count == 0 )
                {
                    MessageBox.Show("Vui lòng chọn một hàng để xóa!");
                    return;
                }
                if(bang_khach.SelectedCells[0].Value != null)
                {
                    string selectedId = bang_khach.SelectedRows[0].Cells["Số CMND Khách"].Value.ToString();
                    // control.ket_noi();
                    string deleteQuery = "DELETE FROM Khach_Hang WHERE cccd_khach = @cccd";
                    SqlCommand command = new SqlCommand(deleteQuery, control_dash_board.pipe_connect);
                    command.Parameters.AddWithValue("@cccd", selectedId);
                    // Thực thi truy vấn xóa
                    command.ExecuteNonQuery();
                    load_bang_khach();
                }
            }
            catch
            {
                MessageBox.Show("Xóa dữ liệu không thành công");
            }
        }
        private void bang_khach_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (bang_khach.SelectedCells[0].Value != null)
            {

                
                try
                {
                    var selectedRow = bang_khach.SelectedRows[0];
                    tb_cccd.Text = selectedRow.Cells["Số CMND Khách"].Value.ToString().Trim();
                    tb_hoten.Text = selectedRow.Cells["Họ Tên Khách"].Value.ToString();
                    tb_sdt.Text = selectedRow.Cells["Số Điện Thoại"].Value.ToString();
                    tb_email.Text = selectedRow.Cells["Email Khách"].Value.ToString();
                    if (selectedRow.Cells["Giới Tính"].Value.ToString() == "Nam")
                        btn_nam.Checked = true;
                    else
                        btn_nu.Checked = true;

                    tb_diachi.Text = selectedRow.Cells["Địa chỉ"].Value.ToString();
                    //Console.WriteLine(DateTime.Parse(selectedRow.Cells["Ngày Sinh"].Value.ToString()).ToString("dd/MM/yyyy"));
                    string s = selectedRow.Cells["Ngày Sinh"].Value.ToString();
                    string[] parts = s.Split('/');
                    int day = int.Parse(parts[0]);
                    int month = int.Parse(parts[1]);
                    int year = int.Parse(parts[2]);

                    // Tạo đối tượng DateTime từ ngày, tháng, năm
                    DateTime date = new DateTime(year, month, day);

                    // Định dạng lại chuỗi ngày tháng theo định dạng mới
                    string newDateFormat = date.ToString("MM/dd/yyyy");
                    tb_ngaysinh.Text = newDateFormat;
                    // Kích hoạt nút sửa
                    sua_khach_button.Enabled = true;

                }
                catch 
                {
                    MessageBox.Show("Dữ liệu chọn không hợp lệ!");
                }
                
            }
           
           
        }


        
    }
}

