﻿namespace Phần_mềm_quản_lí_thuê_xe_ver2
{
    partial class vehicles_uc
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.guna2ShadowPanel1 = new Guna.UI2.WinForms.Guna2ShadowPanel();
            this.bang_xe = new System.Windows.Forms.DataGridView();
            this.them_xe_button = new Guna.UI2.WinForms.Guna2Button();
            this.suaxe = new Guna.UI2.WinForms.Guna2Button();
            this.xoaxe = new Guna.UI2.WinForms.Guna2Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.tb_bienso = new Guna.UI2.WinForms.Guna2TextBox();
            this.tb_tenxe = new Guna.UI2.WinForms.Guna2TextBox();
            this.tb_loaixe = new Guna.UI2.WinForms.Guna2TextBox();
            this.tb_mauxe = new Guna.UI2.WinForms.Guna2TextBox();
            this.tb_socho = new Guna.UI2.WinForms.Guna2TextBox();
            this.tb_hangxe = new Guna.UI2.WinForms.Guna2TextBox();
            this.tb_giathue = new Guna.UI2.WinForms.Guna2TextBox();
            this.tb_tiencoc = new Guna.UI2.WinForms.Guna2TextBox();
            this.comboBox_tenncc = new System.Windows.Forms.ComboBox();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.guna2GradientPanel3 = new Guna.UI2.WinForms.Guna2GradientPanel();
            this.guna2GradientPanel2 = new Guna.UI2.WinForms.Guna2GradientPanel();
            this.guna2GradientPanel1 = new Guna.UI2.WinForms.Guna2GradientPanel();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.guna2ShadowPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bang_xe)).BeginInit();
            this.tableLayoutPanel1.SuspendLayout();
            this.guna2GradientPanel3.SuspendLayout();
            this.guna2GradientPanel2.SuspendLayout();
            this.guna2GradientPanel1.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // guna2ShadowPanel1
            // 
            this.guna2ShadowPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2ShadowPanel1.BackColor = System.Drawing.Color.Transparent;
            this.guna2ShadowPanel1.Controls.Add(this.bang_xe);
            this.guna2ShadowPanel1.FillColor = System.Drawing.Color.White;
            this.guna2ShadowPanel1.Location = new System.Drawing.Point(3, 285);
            this.guna2ShadowPanel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2ShadowPanel1.Name = "guna2ShadowPanel1";
            this.guna2ShadowPanel1.ShadowColor = System.Drawing.Color.Black;
            this.guna2ShadowPanel1.ShadowStyle = Guna.UI2.WinForms.Guna2ShadowPanel.ShadowMode.Dropped;
            this.guna2ShadowPanel1.Size = new System.Drawing.Size(1087, 384);
            this.guna2ShadowPanel1.TabIndex = 0;
            // 
            // bang_xe
            // 
            this.bang_xe.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.bang_xe.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.bang_xe.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.bang_xe.Location = new System.Drawing.Point(3, 2);
            this.bang_xe.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.bang_xe.Name = "bang_xe";
            this.bang_xe.ReadOnly = true;
            this.bang_xe.RowHeadersWidth = 51;
            this.bang_xe.RowTemplate.Height = 24;
            this.bang_xe.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.bang_xe.Size = new System.Drawing.Size(1081, 366);
            this.bang_xe.TabIndex = 0;
            this.bang_xe.Click += new System.EventHandler(this.bang_xe_Click);
            // 
            // them_xe_button
            // 
            this.them_xe_button.Animated = true;
            this.them_xe_button.AutoRoundedCorners = true;
            this.them_xe_button.BorderRadius = 22;
            this.them_xe_button.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.them_xe_button.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.them_xe_button.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.them_xe_button.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.them_xe_button.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.them_xe_button.ForeColor = System.Drawing.Color.White;
            this.them_xe_button.Location = new System.Drawing.Point(39, 4);
            this.them_xe_button.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.them_xe_button.Name = "them_xe_button";
            this.them_xe_button.Size = new System.Drawing.Size(180, 46);
            this.them_xe_button.TabIndex = 1;
            this.them_xe_button.Text = "Thêm xe";
            this.them_xe_button.Click += new System.EventHandler(this.them_xe_button_Click);
            // 
            // suaxe
            // 
            this.suaxe.Animated = true;
            this.suaxe.AutoRoundedCorners = true;
            this.suaxe.BorderRadius = 22;
            this.suaxe.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.suaxe.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.suaxe.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.suaxe.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.suaxe.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.suaxe.ForeColor = System.Drawing.Color.White;
            this.suaxe.Location = new System.Drawing.Point(349, 4);
            this.suaxe.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.suaxe.Name = "suaxe";
            this.suaxe.Size = new System.Drawing.Size(180, 46);
            this.suaxe.TabIndex = 2;
            this.suaxe.Text = "Sửa";
            this.suaxe.Click += new System.EventHandler(this.suaxe_Click);
            // 
            // xoaxe
            // 
            this.xoaxe.Animated = true;
            this.xoaxe.AutoRoundedCorners = true;
            this.xoaxe.BorderRadius = 22;
            this.xoaxe.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.xoaxe.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.xoaxe.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.xoaxe.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.xoaxe.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.xoaxe.ForeColor = System.Drawing.Color.White;
            this.xoaxe.Location = new System.Drawing.Point(659, 5);
            this.xoaxe.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.xoaxe.Name = "xoaxe";
            this.xoaxe.Size = new System.Drawing.Size(180, 46);
            this.xoaxe.TabIndex = 3;
            this.xoaxe.Text = "Xóa xe";
            this.xoaxe.Click += new System.EventHandler(this.xoaxe_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(11, 20);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(66, 20);
            this.label1.TabIndex = 4;
            this.label1.Text = "Biển số";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(11, 69);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(59, 20);
            this.label2.TabIndex = 5;
            this.label2.Text = "Tên xe";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(11, 116);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(63, 20);
            this.label3.TabIndex = 6;
            this.label3.Text = "Loại xe";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(21, 20);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(63, 20);
            this.label4.TabIndex = 7;
            this.label4.Text = "Màu xe";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(21, 69);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(61, 20);
            this.label5.TabIndex = 8;
            this.label5.Text = "Số chỗ";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(21, 116);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(71, 20);
            this.label6.TabIndex = 9;
            this.label6.Text = "Hãng xe";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(12, 20);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(72, 20);
            this.label7.TabIndex = 10;
            this.label7.Text = "Giá thuê";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(12, 69);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(73, 20);
            this.label8.TabIndex = 11;
            this.label8.Text = "Tiền cọc";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(12, 129);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(142, 20);
            this.label9.TabIndex = 12;
            this.label9.Text = "Tên nhà cung cấp";
            // 
            // tb_bienso
            // 
            this.tb_bienso.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tb_bienso.Animated = true;
            this.tb_bienso.AutoRoundedCorners = true;
            this.tb_bienso.BorderRadius = 15;
            this.tb_bienso.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.tb_bienso.DefaultText = "";
            this.tb_bienso.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.tb_bienso.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.tb_bienso.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tb_bienso.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tb_bienso.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tb_bienso.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.tb_bienso.ForeColor = System.Drawing.Color.Black;
            this.tb_bienso.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tb_bienso.Location = new System.Drawing.Point(83, 14);
            this.tb_bienso.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tb_bienso.Name = "tb_bienso";
            this.tb_bienso.PasswordChar = '\0';
            this.tb_bienso.PlaceholderText = "";
            this.tb_bienso.SelectedText = "";
            this.tb_bienso.Size = new System.Drawing.Size(224, 33);
            this.tb_bienso.TabIndex = 13;
            // 
            // tb_tenxe
            // 
            this.tb_tenxe.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tb_tenxe.Animated = true;
            this.tb_tenxe.AutoRoundedCorners = true;
            this.tb_tenxe.BorderRadius = 15;
            this.tb_tenxe.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.tb_tenxe.DefaultText = "";
            this.tb_tenxe.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.tb_tenxe.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.tb_tenxe.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tb_tenxe.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tb_tenxe.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tb_tenxe.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.tb_tenxe.ForeColor = System.Drawing.Color.Black;
            this.tb_tenxe.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tb_tenxe.Location = new System.Drawing.Point(83, 61);
            this.tb_tenxe.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tb_tenxe.Name = "tb_tenxe";
            this.tb_tenxe.PasswordChar = '\0';
            this.tb_tenxe.PlaceholderText = "";
            this.tb_tenxe.SelectedText = "";
            this.tb_tenxe.Size = new System.Drawing.Size(224, 33);
            this.tb_tenxe.TabIndex = 14;
            // 
            // tb_loaixe
            // 
            this.tb_loaixe.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tb_loaixe.Animated = true;
            this.tb_loaixe.AutoRoundedCorners = true;
            this.tb_loaixe.BorderRadius = 15;
            this.tb_loaixe.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.tb_loaixe.DefaultText = "";
            this.tb_loaixe.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.tb_loaixe.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.tb_loaixe.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tb_loaixe.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tb_loaixe.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tb_loaixe.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.tb_loaixe.ForeColor = System.Drawing.Color.Black;
            this.tb_loaixe.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tb_loaixe.Location = new System.Drawing.Point(83, 108);
            this.tb_loaixe.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tb_loaixe.Name = "tb_loaixe";
            this.tb_loaixe.PasswordChar = '\0';
            this.tb_loaixe.PlaceholderText = "";
            this.tb_loaixe.SelectedText = "";
            this.tb_loaixe.Size = new System.Drawing.Size(224, 33);
            this.tb_loaixe.TabIndex = 15;
            // 
            // tb_mauxe
            // 
            this.tb_mauxe.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tb_mauxe.Animated = true;
            this.tb_mauxe.AutoRoundedCorners = true;
            this.tb_mauxe.BorderRadius = 15;
            this.tb_mauxe.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.tb_mauxe.DefaultText = "";
            this.tb_mauxe.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.tb_mauxe.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.tb_mauxe.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tb_mauxe.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tb_mauxe.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tb_mauxe.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.tb_mauxe.ForeColor = System.Drawing.Color.Black;
            this.tb_mauxe.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tb_mauxe.Location = new System.Drawing.Point(110, 14);
            this.tb_mauxe.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tb_mauxe.Name = "tb_mauxe";
            this.tb_mauxe.PasswordChar = '\0';
            this.tb_mauxe.PlaceholderText = "";
            this.tb_mauxe.SelectedText = "";
            this.tb_mauxe.Size = new System.Drawing.Size(224, 33);
            this.tb_mauxe.TabIndex = 16;
            // 
            // tb_socho
            // 
            this.tb_socho.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tb_socho.Animated = true;
            this.tb_socho.AutoRoundedCorners = true;
            this.tb_socho.BorderRadius = 15;
            this.tb_socho.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.tb_socho.DefaultText = "";
            this.tb_socho.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.tb_socho.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.tb_socho.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tb_socho.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tb_socho.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tb_socho.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.tb_socho.ForeColor = System.Drawing.Color.Black;
            this.tb_socho.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tb_socho.Location = new System.Drawing.Point(110, 61);
            this.tb_socho.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tb_socho.Name = "tb_socho";
            this.tb_socho.PasswordChar = '\0';
            this.tb_socho.PlaceholderText = "";
            this.tb_socho.SelectedText = "";
            this.tb_socho.Size = new System.Drawing.Size(224, 33);
            this.tb_socho.TabIndex = 17;
            // 
            // tb_hangxe
            // 
            this.tb_hangxe.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tb_hangxe.Animated = true;
            this.tb_hangxe.AutoRoundedCorners = true;
            this.tb_hangxe.BorderRadius = 15;
            this.tb_hangxe.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.tb_hangxe.DefaultText = "";
            this.tb_hangxe.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.tb_hangxe.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.tb_hangxe.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tb_hangxe.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tb_hangxe.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tb_hangxe.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.tb_hangxe.ForeColor = System.Drawing.Color.Black;
            this.tb_hangxe.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tb_hangxe.Location = new System.Drawing.Point(110, 108);
            this.tb_hangxe.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tb_hangxe.Name = "tb_hangxe";
            this.tb_hangxe.PasswordChar = '\0';
            this.tb_hangxe.PlaceholderText = "";
            this.tb_hangxe.SelectedText = "";
            this.tb_hangxe.Size = new System.Drawing.Size(224, 33);
            this.tb_hangxe.TabIndex = 18;
            // 
            // tb_giathue
            // 
            this.tb_giathue.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tb_giathue.Animated = true;
            this.tb_giathue.AutoRoundedCorners = true;
            this.tb_giathue.BorderRadius = 15;
            this.tb_giathue.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.tb_giathue.DefaultText = "";
            this.tb_giathue.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.tb_giathue.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.tb_giathue.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tb_giathue.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tb_giathue.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tb_giathue.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.tb_giathue.ForeColor = System.Drawing.Color.Black;
            this.tb_giathue.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tb_giathue.Location = new System.Drawing.Point(107, 14);
            this.tb_giathue.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tb_giathue.Name = "tb_giathue";
            this.tb_giathue.PasswordChar = '\0';
            this.tb_giathue.PlaceholderText = "";
            this.tb_giathue.SelectedText = "";
            this.tb_giathue.Size = new System.Drawing.Size(225, 33);
            this.tb_giathue.TabIndex = 19;
            // 
            // tb_tiencoc
            // 
            this.tb_tiencoc.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tb_tiencoc.Animated = true;
            this.tb_tiencoc.AutoRoundedCorners = true;
            this.tb_tiencoc.BorderRadius = 15;
            this.tb_tiencoc.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.tb_tiencoc.DefaultText = "";
            this.tb_tiencoc.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.tb_tiencoc.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.tb_tiencoc.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tb_tiencoc.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tb_tiencoc.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tb_tiencoc.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.tb_tiencoc.ForeColor = System.Drawing.Color.Black;
            this.tb_tiencoc.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tb_tiencoc.Location = new System.Drawing.Point(107, 61);
            this.tb_tiencoc.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tb_tiencoc.Name = "tb_tiencoc";
            this.tb_tiencoc.PasswordChar = '\0';
            this.tb_tiencoc.PlaceholderText = "";
            this.tb_tiencoc.SelectedText = "";
            this.tb_tiencoc.Size = new System.Drawing.Size(225, 33);
            this.tb_tiencoc.TabIndex = 20;
            // 
            // comboBox_tenncc
            // 
            this.comboBox_tenncc.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.comboBox_tenncc.FormattingEnabled = true;
            this.comboBox_tenncc.Location = new System.Drawing.Point(163, 129);
            this.comboBox_tenncc.Margin = new System.Windows.Forms.Padding(4);
            this.comboBox_tenncc.Name = "comboBox_tenncc";
            this.comboBox_tenncc.Size = new System.Drawing.Size(169, 24);
            this.comboBox_tenncc.TabIndex = 21;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel1.Controls.Add(this.guna2GradientPanel3, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.guna2GradientPanel2, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.guna2GradientPanel1, 0, 0);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(6, 21);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1073, 193);
            this.tableLayoutPanel1.TabIndex = 24;
            // 
            // guna2GradientPanel3
            // 
            this.guna2GradientPanel3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2GradientPanel3.Controls.Add(this.tb_giathue);
            this.guna2GradientPanel3.Controls.Add(this.label7);
            this.guna2GradientPanel3.Controls.Add(this.label8);
            this.guna2GradientPanel3.Controls.Add(this.comboBox_tenncc);
            this.guna2GradientPanel3.Controls.Add(this.label9);
            this.guna2GradientPanel3.Controls.Add(this.tb_tiencoc);
            this.guna2GradientPanel3.Location = new System.Drawing.Point(717, 3);
            this.guna2GradientPanel3.Name = "guna2GradientPanel3";
            this.guna2GradientPanel3.Size = new System.Drawing.Size(353, 187);
            this.guna2GradientPanel3.TabIndex = 2;
            // 
            // guna2GradientPanel2
            // 
            this.guna2GradientPanel2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2GradientPanel2.Controls.Add(this.tb_mauxe);
            this.guna2GradientPanel2.Controls.Add(this.label4);
            this.guna2GradientPanel2.Controls.Add(this.label5);
            this.guna2GradientPanel2.Controls.Add(this.label6);
            this.guna2GradientPanel2.Controls.Add(this.tb_socho);
            this.guna2GradientPanel2.Controls.Add(this.tb_hangxe);
            this.guna2GradientPanel2.Location = new System.Drawing.Point(360, 3);
            this.guna2GradientPanel2.Name = "guna2GradientPanel2";
            this.guna2GradientPanel2.Size = new System.Drawing.Size(351, 187);
            this.guna2GradientPanel2.TabIndex = 1;
            // 
            // guna2GradientPanel1
            // 
            this.guna2GradientPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2GradientPanel1.Controls.Add(this.tb_bienso);
            this.guna2GradientPanel1.Controls.Add(this.label1);
            this.guna2GradientPanel1.Controls.Add(this.label2);
            this.guna2GradientPanel1.Controls.Add(this.label3);
            this.guna2GradientPanel1.Controls.Add(this.tb_tenxe);
            this.guna2GradientPanel1.Controls.Add(this.tb_loaixe);
            this.guna2GradientPanel1.Location = new System.Drawing.Point(3, 3);
            this.guna2GradientPanel1.Name = "guna2GradientPanel1";
            this.guna2GradientPanel1.Size = new System.Drawing.Size(351, 187);
            this.guna2GradientPanel1.TabIndex = 0;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel2.ColumnCount = 3;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 900F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Controls.Add(this.panel1, 1, 0);
            this.tableLayoutPanel2.Location = new System.Drawing.Point(3, 220);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 1;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(1087, 60);
            this.tableLayoutPanel2.TabIndex = 25;
            // 
            // panel1
            // 
            this.panel1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.panel1.Controls.Add(this.them_xe_button);
            this.panel1.Controls.Add(this.suaxe);
            this.panel1.Controls.Add(this.xoaxe);
            this.panel1.Location = new System.Drawing.Point(113, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(860, 54);
            this.panel1.TabIndex = 26;
            // 
            // vehicles_uc
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.tableLayoutPanel2);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Controls.Add(this.guna2ShadowPanel1);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "vehicles_uc";
            this.Size = new System.Drawing.Size(1093, 671);
            this.Load += new System.EventHandler(this.vehicles_uc_Load);
            this.guna2ShadowPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.bang_xe)).EndInit();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.guna2GradientPanel3.ResumeLayout(false);
            this.guna2GradientPanel3.PerformLayout();
            this.guna2GradientPanel2.ResumeLayout(false);
            this.guna2GradientPanel2.PerformLayout();
            this.guna2GradientPanel1.ResumeLayout(false);
            this.guna2GradientPanel1.PerformLayout();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private Guna.UI2.WinForms.Guna2ShadowPanel guna2ShadowPanel1;
        private System.Windows.Forms.DataGridView bang_xe;
        private Guna.UI2.WinForms.Guna2Button them_xe_button;
        private Guna.UI2.WinForms.Guna2Button suaxe;
        private Guna.UI2.WinForms.Guna2Button xoaxe;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private Guna.UI2.WinForms.Guna2TextBox tb_bienso;
        private Guna.UI2.WinForms.Guna2TextBox tb_tenxe;
        private Guna.UI2.WinForms.Guna2TextBox tb_loaixe;
        private Guna.UI2.WinForms.Guna2TextBox tb_mauxe;
        private Guna.UI2.WinForms.Guna2TextBox tb_socho;
        private Guna.UI2.WinForms.Guna2TextBox tb_hangxe;
        private Guna.UI2.WinForms.Guna2TextBox tb_giathue;
        private Guna.UI2.WinForms.Guna2TextBox tb_tiencoc;
        private System.Windows.Forms.ComboBox comboBox_tenncc;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private Guna.UI2.WinForms.Guna2GradientPanel guna2GradientPanel3;
        private Guna.UI2.WinForms.Guna2GradientPanel guna2GradientPanel2;
        private Guna.UI2.WinForms.Guna2GradientPanel guna2GradientPanel1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Panel panel1;
    }
}
