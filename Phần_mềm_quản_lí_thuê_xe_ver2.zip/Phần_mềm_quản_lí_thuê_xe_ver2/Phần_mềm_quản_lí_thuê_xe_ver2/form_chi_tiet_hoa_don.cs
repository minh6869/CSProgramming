﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ComponentFactory.Krypton.Toolkit;

namespace Phần_mềm_quản_lí_thuê_xe_ver2
{
    public partial class form_chi_tiet_hoa_don : KryptonForm
    {
        public form_chi_tiet_hoa_don()
        {
            InitializeComponent();
        }

        private void form_chi_tiet_hoa_don_Load(object sender, EventArgs e)
        {

            this.hop_dong_report.RefreshReport();
        }
    }
}
