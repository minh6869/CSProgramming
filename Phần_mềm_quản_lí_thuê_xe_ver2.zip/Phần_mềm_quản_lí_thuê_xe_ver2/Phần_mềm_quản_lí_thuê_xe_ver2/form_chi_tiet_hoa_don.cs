﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Reporting.WinForms;
using ComponentFactory.Krypton.Toolkit;

namespace Phần_mềm_quản_lí_thuê_xe_ver2
{
    public partial class form_chi_tiet_hoa_don : KryptonForm
    {
        public form_chi_tiet_hoa_don()
        {
            InitializeComponent();
        }

        private void form_chi_tiet_hoa_don_Load(object sender, EventArgs e)
        {

            hop_dong_report.LocalReport.ReportPath = "noi_dung_hoa_don.rdlc";
            var source = new ReportDataSource("dataset_info_hopdong", control_dash_board.thongtin);
            hop_dong_report.LocalReport.DataSources.Clear();
            hop_dong_report.LocalReport.DataSources.Add(source);
            this.hop_dong_report.RefreshReport();
        }
    }
}
