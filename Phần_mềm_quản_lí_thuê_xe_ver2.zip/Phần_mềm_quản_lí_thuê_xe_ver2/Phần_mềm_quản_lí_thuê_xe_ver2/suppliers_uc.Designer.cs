﻿namespace Phần_mềm_quản_lí_thuê_xe_ver2
{
    partial class suppliers_uc
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.guna2ShadowPanel1 = new Guna.UI2.WinForms.Guna2ShadowPanel();
            this.bang_nha_cung_cap = new System.Windows.Forms.DataGridView();
            this.guna2ShadowForm1 = new Guna.UI2.WinForms.Guna2ShadowForm(this.components);
            this.themncc_button = new Guna.UI2.WinForms.Guna2Button();
            this.guna2AnimateWindow1 = new Guna.UI2.WinForms.Guna2AnimateWindow(this.components);
            this.sua_ncc_button = new Guna.UI2.WinForms.Guna2Button();
            this.xoa_ncc_button = new Guna.UI2.WinForms.Guna2Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.ten_ncc = new Guna.UI2.WinForms.Guna2TextBox();
            this.sodt_ncc = new Guna.UI2.WinForms.Guna2TextBox();
            this.diachi_ncc = new Guna.UI2.WinForms.Guna2TextBox();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.guna2CustomGradientPanel1 = new Guna.UI2.WinForms.Guna2CustomGradientPanel();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.guna2ShadowPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bang_nha_cung_cap)).BeginInit();
            this.tableLayoutPanel1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.guna2CustomGradientPanel1.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // guna2ShadowPanel1
            // 
            this.guna2ShadowPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2ShadowPanel1.BackColor = System.Drawing.Color.Transparent;
            this.guna2ShadowPanel1.Controls.Add(this.bang_nha_cung_cap);
            this.guna2ShadowPanel1.FillColor = System.Drawing.Color.White;
            this.guna2ShadowPanel1.Location = new System.Drawing.Point(3, 257);
            this.guna2ShadowPanel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2ShadowPanel1.Name = "guna2ShadowPanel1";
            this.guna2ShadowPanel1.ShadowColor = System.Drawing.Color.Black;
            this.guna2ShadowPanel1.ShadowStyle = Guna.UI2.WinForms.Guna2ShadowPanel.ShadowMode.Dropped;
            this.guna2ShadowPanel1.Size = new System.Drawing.Size(1044, 383);
            this.guna2ShadowPanel1.TabIndex = 0;
            // 
            // bang_nha_cung_cap
            // 
            this.bang_nha_cung_cap.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.bang_nha_cung_cap.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.bang_nha_cung_cap.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.bang_nha_cung_cap.Location = new System.Drawing.Point(3, 2);
            this.bang_nha_cung_cap.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.bang_nha_cung_cap.Name = "bang_nha_cung_cap";
            this.bang_nha_cung_cap.ReadOnly = true;
            this.bang_nha_cung_cap.RowHeadersWidth = 51;
            this.bang_nha_cung_cap.RowTemplate.Height = 24;
            this.bang_nha_cung_cap.Size = new System.Drawing.Size(1038, 365);
            this.bang_nha_cung_cap.TabIndex = 0;
            this.bang_nha_cung_cap.Click += new System.EventHandler(this.bang_nha_cung_cap_Click);
            // 
            // themncc_button
            // 
            this.themncc_button.Animated = true;
            this.themncc_button.AutoRoundedCorners = true;
            this.themncc_button.BorderRadius = 19;
            this.themncc_button.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.themncc_button.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.themncc_button.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.themncc_button.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.themncc_button.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.themncc_button.ForeColor = System.Drawing.Color.White;
            this.themncc_button.Location = new System.Drawing.Point(13, 14);
            this.themncc_button.Margin = new System.Windows.Forms.Padding(4);
            this.themncc_button.Name = "themncc_button";
            this.themncc_button.Size = new System.Drawing.Size(187, 41);
            this.themncc_button.TabIndex = 1;
            this.themncc_button.Text = "Thêm nhà cung cấp";
            this.themncc_button.Click += new System.EventHandler(this.them_ncc_button_Click);
            // 
            // sua_ncc_button
            // 
            this.sua_ncc_button.Animated = true;
            this.sua_ncc_button.AutoRoundedCorners = true;
            this.sua_ncc_button.BorderRadius = 19;
            this.sua_ncc_button.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.sua_ncc_button.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.sua_ncc_button.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.sua_ncc_button.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.sua_ncc_button.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.sua_ncc_button.ForeColor = System.Drawing.Color.White;
            this.sua_ncc_button.Location = new System.Drawing.Point(322, 14);
            this.sua_ncc_button.Margin = new System.Windows.Forms.Padding(4);
            this.sua_ncc_button.Name = "sua_ncc_button";
            this.sua_ncc_button.Size = new System.Drawing.Size(187, 41);
            this.sua_ncc_button.TabIndex = 2;
            this.sua_ncc_button.Text = "Sửa";
            this.sua_ncc_button.Click += new System.EventHandler(this.sua_ncc_button_Click);
            // 
            // xoa_ncc_button
            // 
            this.xoa_ncc_button.Animated = true;
            this.xoa_ncc_button.AutoRoundedCorners = true;
            this.xoa_ncc_button.BorderRadius = 19;
            this.xoa_ncc_button.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.xoa_ncc_button.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.xoa_ncc_button.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.xoa_ncc_button.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.xoa_ncc_button.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.xoa_ncc_button.ForeColor = System.Drawing.Color.White;
            this.xoa_ncc_button.Location = new System.Drawing.Point(631, 14);
            this.xoa_ncc_button.Margin = new System.Windows.Forms.Padding(4);
            this.xoa_ncc_button.Name = "xoa_ncc_button";
            this.xoa_ncc_button.Size = new System.Drawing.Size(187, 41);
            this.xoa_ncc_button.TabIndex = 3;
            this.xoa_ncc_button.Text = "Xóa nhà cung cấp";
            this.xoa_ncc_button.Click += new System.EventHandler(this.xoa_ncc_button_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(36, 58);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(114, 16);
            this.label1.TabIndex = 4;
            this.label1.Text = "Tên nhà cung cấp";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(57, 113);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(47, 16);
            this.label2.TabIndex = 5;
            this.label2.Text = "Địa chỉ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(57, 36);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(85, 16);
            this.label3.TabIndex = 6;
            this.label3.Text = "Số điện thoại";
            // 
            // ten_ncc
            // 
            this.ten_ncc.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ten_ncc.Animated = true;
            this.ten_ncc.AutoRoundedCorners = true;
            this.ten_ncc.BorderRadius = 16;
            this.ten_ncc.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.ten_ncc.DefaultText = "";
            this.ten_ncc.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.ten_ncc.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.ten_ncc.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.ten_ncc.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.ten_ncc.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.ten_ncc.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.ten_ncc.ForeColor = System.Drawing.Color.Black;
            this.ten_ncc.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.ten_ncc.Location = new System.Drawing.Point(186, 53);
            this.ten_ncc.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.ten_ncc.Name = "ten_ncc";
            this.ten_ncc.PasswordChar = '\0';
            this.ten_ncc.PlaceholderText = "";
            this.ten_ncc.SelectedText = "";
            this.ten_ncc.Size = new System.Drawing.Size(197, 34);
            this.ten_ncc.TabIndex = 7;
            // 
            // sodt_ncc
            // 
            this.sodt_ncc.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.sodt_ncc.Animated = true;
            this.sodt_ncc.AutoRoundedCorners = true;
            this.sodt_ncc.BorderRadius = 16;
            this.sodt_ncc.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.sodt_ncc.DefaultText = "";
            this.sodt_ncc.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.sodt_ncc.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.sodt_ncc.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.sodt_ncc.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.sodt_ncc.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.sodt_ncc.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.sodt_ncc.ForeColor = System.Drawing.Color.Black;
            this.sodt_ncc.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.sodt_ncc.Location = new System.Drawing.Point(181, 31);
            this.sodt_ncc.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.sodt_ncc.Name = "sodt_ncc";
            this.sodt_ncc.PasswordChar = '\0';
            this.sodt_ncc.PlaceholderText = "";
            this.sodt_ncc.SelectedText = "";
            this.sodt_ncc.Size = new System.Drawing.Size(197, 34);
            this.sodt_ncc.TabIndex = 8;
            // 
            // diachi_ncc
            // 
            this.diachi_ncc.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.diachi_ncc.Animated = true;
            this.diachi_ncc.AutoRoundedCorners = true;
            this.diachi_ncc.BorderRadius = 16;
            this.diachi_ncc.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.diachi_ncc.DefaultText = "";
            this.diachi_ncc.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.diachi_ncc.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.diachi_ncc.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.diachi_ncc.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.diachi_ncc.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.diachi_ncc.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.diachi_ncc.ForeColor = System.Drawing.Color.Black;
            this.diachi_ncc.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.diachi_ncc.Location = new System.Drawing.Point(181, 113);
            this.diachi_ncc.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.diachi_ncc.Name = "diachi_ncc";
            this.diachi_ncc.PasswordChar = '\0';
            this.diachi_ncc.PlaceholderText = "";
            this.diachi_ncc.SelectedText = "";
            this.diachi_ncc.Size = new System.Drawing.Size(197, 34);
            this.diachi_ncc.TabIndex = 9;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Controls.Add(this.panel1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.panel2, 1, 0);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(13, 3);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1023, 171);
            this.tableLayoutPanel1.TabIndex = 10;
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.Controls.Add(this.ten_ncc);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(3, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(505, 165);
            this.panel1.TabIndex = 0;
            // 
            // panel2
            // 
            this.panel2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel2.Controls.Add(this.sodt_ncc);
            this.panel2.Controls.Add(this.diachi_ncc);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Location = new System.Drawing.Point(514, 3);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(506, 165);
            this.panel2.TabIndex = 1;
            // 
            // guna2CustomGradientPanel1
            // 
            this.guna2CustomGradientPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2CustomGradientPanel1.Controls.Add(this.xoa_ncc_button);
            this.guna2CustomGradientPanel1.Controls.Add(this.sua_ncc_button);
            this.guna2CustomGradientPanel1.Controls.Add(this.themncc_button);
            this.guna2CustomGradientPanel1.Location = new System.Drawing.Point(97, 3);
            this.guna2CustomGradientPanel1.Name = "guna2CustomGradientPanel1";
            this.guna2CustomGradientPanel1.Size = new System.Drawing.Size(828, 69);
            this.guna2CustomGradientPanel1.TabIndex = 11;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel2.ColumnCount = 3;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 834F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Controls.Add(this.guna2CustomGradientPanel1, 1, 0);
            this.tableLayoutPanel2.Location = new System.Drawing.Point(13, 180);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 1;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(1023, 75);
            this.tableLayoutPanel2.TabIndex = 12;
            // 
            // suppliers_uc
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.tableLayoutPanel2);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Controls.Add(this.guna2ShadowPanel1);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "suppliers_uc";
            this.Size = new System.Drawing.Size(1046, 642);
            this.Load += new System.EventHandler(this.suppliers_uc_Load);
            this.guna2ShadowPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.bang_nha_cung_cap)).EndInit();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.guna2CustomGradientPanel1.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private Guna.UI2.WinForms.Guna2ShadowPanel guna2ShadowPanel1;
        private System.Windows.Forms.DataGridView bang_nha_cung_cap;
        private Guna.UI2.WinForms.Guna2ShadowForm guna2ShadowForm1;
        private Guna.UI2.WinForms.Guna2Button themncc_button;
        private Guna.UI2.WinForms.Guna2AnimateWindow guna2AnimateWindow1;
        private Guna.UI2.WinForms.Guna2Button sua_ncc_button;
        private Guna.UI2.WinForms.Guna2Button xoa_ncc_button;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private Guna.UI2.WinForms.Guna2TextBox ten_ncc;
        private Guna.UI2.WinForms.Guna2TextBox sodt_ncc;
        private Guna.UI2.WinForms.Guna2TextBox diachi_ncc;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private Guna.UI2.WinForms.Guna2CustomGradientPanel guna2CustomGradientPanel1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
    }
}
