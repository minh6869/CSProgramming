﻿namespace Phần_mềm_quản_lí_thuê_xe_ver2
{
    partial class home
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.guna2Panel1 = new Guna.UI2.WinForms.Guna2Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.dia_diem_combobox = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.welcom_label = new System.Windows.Forms.Label();
            this.bien_xe_combobox = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.cccd_khach_combobox = new System.Windows.Forms.ComboBox();
            this.tra_xe_button = new Guna.UI2.WinForms.Guna2Button();
            this.tao_hop_dong_button = new Guna.UI2.WinForms.Guna2Button();
            this.search_button = new Guna.UI2.WinForms.Guna2Button();
            this.search_bar = new Guna.UI2.WinForms.Guna2TextBox();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.guna2ShadowPanel1 = new Guna.UI2.WinForms.Guna2ShadowPanel();
            this.bang_cho_thue = new System.Windows.Forms.DataGridView();
            this.so_ngay_thue_num = new Guna.UI2.WinForms.Guna2NumericUpDown();
            this.guna2Panel1.SuspendLayout();
            this.guna2ShadowPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bang_cho_thue)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.so_ngay_thue_num)).BeginInit();
            this.SuspendLayout();
            // 
            // guna2Panel1
            // 
            this.guna2Panel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2Panel1.Controls.Add(this.so_ngay_thue_num);
            this.guna2Panel1.Controls.Add(this.label4);
            this.guna2Panel1.Controls.Add(this.dia_diem_combobox);
            this.guna2Panel1.Controls.Add(this.label3);
            this.guna2Panel1.Controls.Add(this.welcom_label);
            this.guna2Panel1.Controls.Add(this.bien_xe_combobox);
            this.guna2Panel1.Controls.Add(this.label2);
            this.guna2Panel1.Controls.Add(this.label1);
            this.guna2Panel1.Controls.Add(this.cccd_khach_combobox);
            this.guna2Panel1.Controls.Add(this.tra_xe_button);
            this.guna2Panel1.Controls.Add(this.tao_hop_dong_button);
            this.guna2Panel1.Controls.Add(this.search_button);
            this.guna2Panel1.Controls.Add(this.search_bar);
            this.guna2Panel1.Controls.Add(this.dateTimePicker1);
            this.guna2Panel1.Controls.Add(this.guna2ShadowPanel1);
            this.guna2Panel1.Location = new System.Drawing.Point(3, 6);
            this.guna2Panel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2Panel1.Name = "guna2Panel1";
            this.guna2Panel1.Size = new System.Drawing.Size(1140, 648);
            this.guna2Panel1.TabIndex = 0;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(495, 181);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(102, 16);
            this.label4.TabIndex = 15;
            this.label4.Text = "Số ngày thuê xe";
            // 
            // dia_diem_combobox
            // 
            this.dia_diem_combobox.FormattingEnabled = true;
            this.dia_diem_combobox.Location = new System.Drawing.Point(678, 102);
            this.dia_diem_combobox.Name = "dia_diem_combobox";
            this.dia_diem_combobox.Size = new System.Drawing.Size(192, 24);
            this.dia_diem_combobox.TabIndex = 14;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(501, 105);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(148, 16);
            this.label3.TabIndex = 13;
            this.label3.Text = "Địa điểm khách nhận xe";
            // 
            // welcom_label
            // 
            this.welcom_label.AutoSize = true;
            this.welcom_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.welcom_label.Location = new System.Drawing.Point(20, 20);
            this.welcom_label.Name = "welcom_label";
            this.welcom_label.Size = new System.Drawing.Size(64, 22);
            this.welcom_label.TabIndex = 12;
            this.welcom_label.Text = "label4";
            // 
            // bien_xe_combobox
            // 
            this.bien_xe_combobox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.bien_xe_combobox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.bien_xe_combobox.FormattingEnabled = true;
            this.bien_xe_combobox.Location = new System.Drawing.Point(193, 181);
            this.bien_xe_combobox.Name = "bien_xe_combobox";
            this.bien_xe_combobox.Size = new System.Drawing.Size(179, 24);
            this.bien_xe_combobox.TabIndex = 9;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(80, 184);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(69, 16);
            this.label2.TabIndex = 8;
            this.label2.Text = "Biển số xe";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(80, 105);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(107, 16);
            this.label1.TabIndex = 7;
            this.label1.Text = "Số CMND Khách";
            // 
            // cccd_khach_combobox
            // 
            this.cccd_khach_combobox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cccd_khach_combobox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cccd_khach_combobox.FormattingEnabled = true;
            this.cccd_khach_combobox.Location = new System.Drawing.Point(231, 97);
            this.cccd_khach_combobox.Name = "cccd_khach_combobox";
            this.cccd_khach_combobox.Size = new System.Drawing.Size(166, 24);
            this.cccd_khach_combobox.TabIndex = 6;
            // 
            // tra_xe_button
            // 
            this.tra_xe_button.Animated = true;
            this.tra_xe_button.AutoRoundedCorners = true;
            this.tra_xe_button.BorderRadius = 21;
            this.tra_xe_button.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.tra_xe_button.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.tra_xe_button.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.tra_xe_button.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.tra_xe_button.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.tra_xe_button.ForeColor = System.Drawing.Color.White;
            this.tra_xe_button.Location = new System.Drawing.Point(926, 222);
            this.tra_xe_button.Name = "tra_xe_button";
            this.tra_xe_button.Size = new System.Drawing.Size(180, 45);
            this.tra_xe_button.TabIndex = 5;
            this.tra_xe_button.Text = "Trả xe";
            // 
            // tao_hop_dong_button
            // 
            this.tao_hop_dong_button.Animated = true;
            this.tao_hop_dong_button.AutoRoundedCorners = true;
            this.tao_hop_dong_button.BorderRadius = 21;
            this.tao_hop_dong_button.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.tao_hop_dong_button.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.tao_hop_dong_button.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.tao_hop_dong_button.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.tao_hop_dong_button.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.tao_hop_dong_button.ForeColor = System.Drawing.Color.White;
            this.tao_hop_dong_button.Location = new System.Drawing.Point(740, 222);
            this.tao_hop_dong_button.Name = "tao_hop_dong_button";
            this.tao_hop_dong_button.Size = new System.Drawing.Size(180, 45);
            this.tao_hop_dong_button.TabIndex = 4;
            this.tao_hop_dong_button.Text = "Tạo hợp đồng thuê";
            this.tao_hop_dong_button.Click += new System.EventHandler(this.tao_hop_dong_button_Click);
            // 
            // search_button
            // 
            this.search_button.Animated = true;
            this.search_button.AutoRoundedCorners = true;
            this.search_button.BackColor = System.Drawing.Color.Transparent;
            this.search_button.BorderRadius = 21;
            this.search_button.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.search_button.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.search_button.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.search_button.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.search_button.FillColor = System.Drawing.Color.DarkCyan;
            this.search_button.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.search_button.ForeColor = System.Drawing.Color.White;
            this.search_button.Location = new System.Drawing.Point(939, 9);
            this.search_button.Name = "search_button";
            this.search_button.Size = new System.Drawing.Size(180, 45);
            this.search_button.TabIndex = 3;
            this.search_button.Text = "Tìm kiếm";
            // 
            // search_bar
            // 
            this.search_bar.Animated = true;
            this.search_bar.AutoRoundedCorners = true;
            this.search_bar.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.search_bar.BorderRadius = 23;
            this.search_bar.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.search_bar.DefaultText = "";
            this.search_bar.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.search_bar.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.search_bar.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.search_bar.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.search_bar.FillColor = System.Drawing.Color.Gainsboro;
            this.search_bar.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.search_bar.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.search_bar.ForeColor = System.Drawing.Color.Black;
            this.search_bar.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.search_bar.Location = new System.Drawing.Point(597, 6);
            this.search_bar.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.search_bar.Name = "search_bar";
            this.search_bar.PasswordChar = '\0';
            this.search_bar.PlaceholderText = "Nhập thông tin";
            this.search_bar.SelectedText = "";
            this.search_bar.Size = new System.Drawing.Size(300, 48);
            this.search_bar.TabIndex = 2;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.CustomFormat = "dd/MM/yyyy";
            this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker1.Location = new System.Drawing.Point(340, 241);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(200, 22);
            this.dateTimePicker1.TabIndex = 1;
            // 
            // guna2ShadowPanel1
            // 
            this.guna2ShadowPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2ShadowPanel1.BackColor = System.Drawing.Color.Transparent;
            this.guna2ShadowPanel1.Controls.Add(this.bang_cho_thue);
            this.guna2ShadowPanel1.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(242)))), ((int)(((byte)(246)))));
            this.guna2ShadowPanel1.Location = new System.Drawing.Point(3, 273);
            this.guna2ShadowPanel1.Name = "guna2ShadowPanel1";
            this.guna2ShadowPanel1.ShadowColor = System.Drawing.Color.Black;
            this.guna2ShadowPanel1.ShadowStyle = Guna.UI2.WinForms.Guna2ShadowPanel.ShadowMode.Dropped;
            this.guna2ShadowPanel1.Size = new System.Drawing.Size(1137, 379);
            this.guna2ShadowPanel1.TabIndex = 1;
            // 
            // bang_cho_thue
            // 
            this.bang_cho_thue.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.bang_cho_thue.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.bang_cho_thue.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.bang_cho_thue.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.bang_cho_thue.Location = new System.Drawing.Point(3, 7);
            this.bang_cho_thue.Name = "bang_cho_thue";
            this.bang_cho_thue.ReadOnly = true;
            this.bang_cho_thue.RowHeadersWidth = 51;
            this.bang_cho_thue.RowTemplate.Height = 24;
            this.bang_cho_thue.Size = new System.Drawing.Size(1133, 357);
            this.bang_cho_thue.TabIndex = 0;
            this.bang_cho_thue.RowHeaderMouseDoubleClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.bang_cho_thue_RowHeaderMouseDoubleClick);
            // 
            // so_ngay_thue_num
            // 
            this.so_ngay_thue_num.AutoRoundedCorners = true;
            this.so_ngay_thue_num.BackColor = System.Drawing.Color.Transparent;
            this.so_ngay_thue_num.BorderRadius = 15;
            this.so_ngay_thue_num.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.so_ngay_thue_num.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.so_ngay_thue_num.Location = new System.Drawing.Point(639, 173);
            this.so_ngay_thue_num.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.so_ngay_thue_num.Name = "so_ngay_thue_num";
            this.so_ngay_thue_num.Size = new System.Drawing.Size(94, 32);
            this.so_ngay_thue_num.TabIndex = 17;
            this.so_ngay_thue_num.UseTransparentBackground = true;
            // 
            // home
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.guna2Panel1);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "home";
            this.Size = new System.Drawing.Size(1146, 666);
            this.Load += new System.EventHandler(this.home_Load);
            this.guna2Panel1.ResumeLayout(false);
            this.guna2Panel1.PerformLayout();
            this.guna2ShadowPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.bang_cho_thue)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.so_ngay_thue_num)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private Guna.UI2.WinForms.Guna2Panel guna2Panel1;
        private Guna.UI2.WinForms.Guna2ShadowPanel guna2ShadowPanel1;
        private System.Windows.Forms.DataGridView bang_cho_thue;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private Guna.UI2.WinForms.Guna2TextBox search_bar;
        private Guna.UI2.WinForms.Guna2Button tao_hop_dong_button;
        private Guna.UI2.WinForms.Guna2Button search_button;
        private Guna.UI2.WinForms.Guna2Button tra_xe_button;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cccd_khach_combobox;
        private System.Windows.Forms.ComboBox bien_xe_combobox;
        private System.Windows.Forms.Label welcom_label;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox dia_diem_combobox;
        private System.Windows.Forms.Label label3;
        private Guna.UI2.WinForms.Guna2NumericUpDown so_ngay_thue_num;
    }
}
