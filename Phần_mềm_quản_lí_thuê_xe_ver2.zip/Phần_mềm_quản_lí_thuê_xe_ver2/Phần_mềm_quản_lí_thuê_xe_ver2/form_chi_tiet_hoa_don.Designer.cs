﻿namespace Phần_mềm_quản_lí_thuê_xe_ver2
{
    partial class form_chi_tiet_hoa_don
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.form_hoa_don_palette = new ComponentFactory.Krypton.Toolkit.KryptonPalette(this.components);
            this.hop_dong_report = new Microsoft.Reporting.WinForms.ReportViewer();
            this.SuspendLayout();
            // 
            // form_hoa_don_palette
            // 
            this.form_hoa_don_palette.ButtonSpecs.FormClose.Image = global::Phần_mềm_quản_lí_thuê_xe_ver2.Properties.Resources.close1;
            this.form_hoa_don_palette.ButtonSpecs.FormClose.ImageStates.ImagePressed = global::Phần_mềm_quản_lí_thuê_xe_ver2.Properties.Resources.close2;
            this.form_hoa_don_palette.ButtonSpecs.FormClose.ImageStates.ImageTracking = global::Phần_mềm_quản_lí_thuê_xe_ver2.Properties.Resources.close2;
            this.form_hoa_don_palette.ButtonSpecs.FormMax.Image = global::Phần_mềm_quản_lí_thuê_xe_ver2.Properties.Resources.max1;
            this.form_hoa_don_palette.ButtonSpecs.FormMax.ImageStates.ImagePressed = global::Phần_mềm_quản_lí_thuê_xe_ver2.Properties.Resources.max2;
            this.form_hoa_don_palette.ButtonSpecs.FormMax.ImageStates.ImageTracking = global::Phần_mềm_quản_lí_thuê_xe_ver2.Properties.Resources.max2;
            this.form_hoa_don_palette.ButtonSpecs.FormMin.Image = global::Phần_mềm_quản_lí_thuê_xe_ver2.Properties.Resources.mini1;
            this.form_hoa_don_palette.ButtonSpecs.FormMin.ImageStates.ImagePressed = global::Phần_mềm_quản_lí_thuê_xe_ver2.Properties.Resources.mini2;
            this.form_hoa_don_palette.ButtonSpecs.FormMin.ImageStates.ImageTracking = global::Phần_mềm_quản_lí_thuê_xe_ver2.Properties.Resources.mini2;
            this.form_hoa_don_palette.ButtonStyles.ButtonForm.StateNormal.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(254)))), ((int)(((byte)(254)))));
            this.form_hoa_don_palette.ButtonStyles.ButtonForm.StateNormal.Back.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(254)))), ((int)(((byte)(254)))));
            this.form_hoa_don_palette.ButtonStyles.ButtonForm.StateNormal.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.form_hoa_don_palette.ButtonStyles.ButtonForm.StateNormal.Border.Width = 0;
            this.form_hoa_don_palette.ButtonStyles.ButtonForm.StatePressed.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(254)))), ((int)(((byte)(254)))));
            this.form_hoa_don_palette.ButtonStyles.ButtonForm.StatePressed.Back.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(254)))), ((int)(((byte)(254)))));
            this.form_hoa_don_palette.ButtonStyles.ButtonForm.StatePressed.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.form_hoa_don_palette.ButtonStyles.ButtonForm.StatePressed.Border.Width = 0;
            this.form_hoa_don_palette.ButtonStyles.ButtonForm.StateTracking.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(254)))), ((int)(((byte)(254)))));
            this.form_hoa_don_palette.ButtonStyles.ButtonForm.StateTracking.Back.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(254)))), ((int)(((byte)(254)))));
            this.form_hoa_don_palette.ButtonStyles.ButtonForm.StateTracking.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.form_hoa_don_palette.ButtonStyles.ButtonForm.StateTracking.Border.Width = 0;
            this.form_hoa_don_palette.ButtonStyles.ButtonFormClose.StatePressed.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(254)))), ((int)(((byte)(254)))));
            this.form_hoa_don_palette.ButtonStyles.ButtonFormClose.StatePressed.Back.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(254)))), ((int)(((byte)(254)))));
            this.form_hoa_don_palette.ButtonStyles.ButtonFormClose.StatePressed.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.form_hoa_don_palette.ButtonStyles.ButtonFormClose.StatePressed.Border.Width = 0;
            this.form_hoa_don_palette.ButtonStyles.ButtonFormClose.StateTracking.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(254)))), ((int)(((byte)(254)))));
            this.form_hoa_don_palette.ButtonStyles.ButtonFormClose.StateTracking.Back.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(254)))), ((int)(((byte)(254)))));
            this.form_hoa_don_palette.ButtonStyles.ButtonFormClose.StateTracking.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.form_hoa_don_palette.ButtonStyles.ButtonFormClose.StateTracking.Border.Width = 0;
            this.form_hoa_don_palette.FormStyles.FormMain.StateCommon.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(254)))), ((int)(((byte)(254)))));
            this.form_hoa_don_palette.FormStyles.FormMain.StateCommon.Back.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(254)))), ((int)(((byte)(254)))));
            this.form_hoa_don_palette.FormStyles.FormMain.StateCommon.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.form_hoa_don_palette.FormStyles.FormMain.StateCommon.Border.GraphicsHint = ComponentFactory.Krypton.Toolkit.PaletteGraphicsHint.None;
            this.form_hoa_don_palette.FormStyles.FormMain.StateCommon.Border.Rounding = 12;
            this.form_hoa_don_palette.HeaderStyles.HeaderForm.StateCommon.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(254)))), ((int)(((byte)(254)))));
            this.form_hoa_don_palette.HeaderStyles.HeaderForm.StateCommon.Back.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(254)))), ((int)(((byte)(254)))));
            this.form_hoa_don_palette.HeaderStyles.HeaderForm.StateCommon.ButtonEdgeInset = 10;
            this.form_hoa_don_palette.HeaderStyles.HeaderForm.StateCommon.Content.Padding = new System.Windows.Forms.Padding(10, -1, -1, -1);
            // 
            // hop_dong_report
            // 
            this.hop_dong_report.Dock = System.Windows.Forms.DockStyle.Fill;
            this.hop_dong_report.LocalReport.ReportEmbeddedResource = "Phần_mềm_quản_lí_thuê_xe_ver2.noi_dung_hoa_don.rdlc";
            this.hop_dong_report.Location = new System.Drawing.Point(0, 0);
            this.hop_dong_report.Name = "hop_dong_report";
            this.hop_dong_report.ServerReport.BearerToken = null;
            this.hop_dong_report.Size = new System.Drawing.Size(1103, 573);
            this.hop_dong_report.TabIndex = 0;
            // 
            // form_chi_tiet_hoa_don
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1103, 573);
            this.Controls.Add(this.hop_dong_report);
            this.Name = "form_chi_tiet_hoa_don";
            this.Palette = this.form_hoa_don_palette;
            this.PaletteMode = ComponentFactory.Krypton.Toolkit.PaletteMode.Custom;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Chi tiết hóa đơn";
            this.Load += new System.EventHandler(this.form_chi_tiet_hoa_don_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private ComponentFactory.Krypton.Toolkit.KryptonPalette form_hoa_don_palette;
        private Microsoft.Reporting.WinForms.ReportViewer hop_dong_report;
    }
}