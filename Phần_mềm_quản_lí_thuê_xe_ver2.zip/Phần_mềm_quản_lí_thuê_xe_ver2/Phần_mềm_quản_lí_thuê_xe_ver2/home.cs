﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Phần_mềm_quản_lí_thuê_xe_ver2
{
    public partial class home : UserControl
    {
        DataTable data_table_bang_cho_thue = new DataTable();
        control_dash_board control = new control_dash_board();
        List<string> list_cccd_khach = new List<string>();
        List<string> list_bien_so_xe = new List<string>();


        
        public home()
        {
            InitializeComponent();
        }



        private void load_bang_cho_thue()
        {
            DataTable temp = new DataTable();
            using(SqlCommand query = new SqlCommand())
            {
                string bien_so, cccd_khach, cccd_nv, dia_diem;
                DateTime ngay_thue,ngay_tra_du_kien;
                int so_ngay_thue = 0;
                query.Connection = control_dash_board.pipe_connect;
                query.CommandText = $@"SELECT * FROM Bang_Thue_Xe";
                //string cmd = $@"SELECT * FROM Bang_Thue_Xe";
                //SqlDataAdapter adapter = new SqlDataAdapter(cmd,control_dash_board.pipe_connect);
                //adapter.Fill(temp);
                SqlDataReader reader = query.ExecuteReader();
                while (reader.Read())
                {
                    bien_so = reader["bien_so"].ToString();
                    cccd_khach = reader["cccd_khach"].ToString();
                    cccd_nv = reader["cccd_nv"].ToString();
                    dia_diem = reader["dia_diem_trao_xe"].ToString();
                    ngay_thue = DateTime.Parse(reader["ngay_thue"].ToString());
                    so_ngay_thue = int.Parse(reader["so_ngay_thue"].ToString());
                    ngay_tra_du_kien = ngay_thue.AddDays(so_ngay_thue);
                    Console.WriteLine(ngay_thue);
                    Console.WriteLine(DateTime.Now);
                    //temp.Rows.Add(ngay_thue);
                    SqlCommand query1 = new SqlCommand();
                    query1.Connection = control_dash_board.pipe_connect;
                    query1.CommandText = $@"SELECT  Xe.ten_xe,
                                                    Xe.so_cho,
                                                    Xe.bien_so,
                                                    Khach_Hang.ho_ten as ho_ten_khach,
                                                    Khach_Hang.sdt as sdt_khach,
                                                    Nhan_Vien.ho_ten as ho_ten_nv
                                            FROM Xe, Khach_Hang, Nhan_Vien
                                            WHERE Xe.bien_so = '{bien_so}' 
                                            AND Khach_Hang.cccd_khach = '{cccd_khach}'
                                            AND Nhan_Vien.cccd_nv = '{cccd_nv}'";
                    SqlDataReader reader1 = query1.ExecuteReader();
                    while(reader1.Read())
                    {
                        data_table_bang_cho_thue.Rows.Add(reader1[0].ToString(), reader1[1].ToString(), reader1[2].ToString(), reader1[3].ToString(), reader1[4].ToString(), reader1[5].ToString(),dia_diem,ngay_thue.ToString("dd/MM/yyyy"),so_ngay_thue,ngay_tra_du_kien.ToString("dd/MM/yyyy"));
                        //control_dash_board.thongtin.tenXe = reader1[0].ToString();
                        //control_dash_board.thongtin.soCho = int.Parse(reader1[1].ToString());
                        //control_dash_board.thongtin.bienSo = reader1[2].ToString();
                        //control_dash_board.thongtin.hoTenKhach = reader1[3].ToString();
                        //control_dash_board.thongtin.hoTenNhanVien = reader1[5].ToString();
                    }
                    reader1.Close();
                }
                reader.Close();
                //reader.Close();
            }

            bang_cho_thue.DataSource = data_table_bang_cho_thue;
        }
        private void load_cccd_khach()
        {
            using (SqlCommand query = new SqlCommand())
            {
                List<string> list_temp = new List<string>();
                query.CommandText = $@"SELECT  cccd_khach FROM Khach_Hang";
                query.Connection = control_dash_board.pipe_connect;
                SqlDataReader reader = query.ExecuteReader();
                while(reader.Read())
                {
                    list_temp.Add(reader[0].ToString());
                }
                reader.Close();
                list_cccd_khach = list_temp;
                cccd_khach_combobox.DataSource = list_cccd_khach;
                cccd_khach_combobox.Text = "";

            }
        }

        private void load_bien_so_xe()
        {
            using(SqlCommand query = new SqlCommand())
            {
                List<string> list_temp = new List<string>();
                query.CommandText = @"SELECT bien_so FROM Xe
                                      WHERE trang_thai = '1'";
                query.Connection = control_dash_board.pipe_connect;
                SqlDataReader reader = query.ExecuteReader();
                while(reader.Read())
                {
                    list_temp.Add(reader[0].ToString().Trim());
                }
                reader.Close();
                list_bien_so_xe = list_temp;
                bien_xe_combobox.DataSource = list_bien_so_xe;
                bien_xe_combobox.Text = "";
            }
        }





        private void home_Load(object sender, EventArgs e)
        {
            
            // bang_cho_thue.DataSource = data_table_bang_cho_thue;
            data_table_bang_cho_thue.Columns.Add("Tên xe",typeof(string));
            data_table_bang_cho_thue.Columns.Add("Số chỗ", typeof(string));
            data_table_bang_cho_thue.Columns.Add("Biển xe", typeof(string));
            data_table_bang_cho_thue.Columns.Add("Họ tên khách", typeof(string));
            data_table_bang_cho_thue.Columns.Add("Số điện thoại khách", typeof(string));
            data_table_bang_cho_thue.Columns.Add("Họ tên nhân viên cho thuê", typeof(string));
            data_table_bang_cho_thue.Columns.Add("Địa điểm cho thuê xe", typeof(string));
            data_table_bang_cho_thue.Columns.Add("Ngày Thuê", typeof(string));
            data_table_bang_cho_thue.Columns.Add("Số Ngày Thuê", typeof(int));
            data_table_bang_cho_thue.Columns.Add("Ngày trả dự kiến", typeof(string));


            load_bang_cho_thue();
            load_cccd_khach();
            load_bien_so_xe();
            welcom_label.Text = $"Xin chào nhân viên: {control_dash_board.username_session} \nSố CMND: {control_dash_board.cccd_session}";


        }

        private void bang_cho_thue_RowHeaderMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            thong_tin_hop_dong temp = new thong_tin_hop_dong();
            Console.WriteLine(bang_cho_thue.SelectedRows[0].Cells[0].Value);
            temp.tenXe = bang_cho_thue.SelectedRows[0].Cells[0].Value.ToString();
            temp.soCho = bang_cho_thue.SelectedRows[0].Cells[1].Value.ToString();
            temp.bienSo = bang_cho_thue.SelectedRows[0].Cells[2].Value.ToString();
            temp.hoTenKhach = bang_cho_thue.SelectedRows[0].Cells[3].Value.ToString();
            temp.sdt = bang_cho_thue.SelectedRows[0].Cells[4].Value.ToString();
            temp.gioiTinh = bang_cho_thue.SelectedRows[0].Cells[5].Value.ToString();
            temp.hoTenNhanVien = bang_cho_thue.SelectedRows[0].Cells[5].Value.ToString();
            temp.diaDiemThueXe = bang_cho_thue.SelectedRows[0].Cells[6].Value.ToString();
            temp.ngayThue = bang_cho_thue.SelectedRows[0].Cells[7].Value.ToString();
            temp.soNgayThue = bang_cho_thue.SelectedRows[0].Cells[8].Value.ToString();
            temp.ngayTraDuKien = bang_cho_thue.SelectedRows[0].Cells[9].Value.ToString();
            using (SqlCommand query = new SqlCommand())
            {
                query.CommandText = $@"SELECT Khach_Hang.cccd_khach, 
	                                         Khach_Hang.gioi_tinh,
	                                         Khach_Hang.que_quan,
	                                         Khach_Hang.email, 
                                             Xe.gia_thue, 
                                             Xe.tien_coc,
	                                         Bang_Thue_Xe.ngay_thue,
                                             Bang_Thue_Xe.cccd_nv
                                      FROM Khach_Hang, Bang_Thue_Xe, Xe
                                      WHERE Bang_Thue_Xe.bien_so = '{temp.bienSo}'
                                      AND Bang_Thue_Xe.cccd_khach = Khach_Hang.cccd_khach
                                      AND Xe.bien_so = '{temp.bienSo}'";
                query.Connection = control_dash_board.pipe_connect;
                SqlDataReader reader = query.ExecuteReader();
                while (reader.Read())
                {
                    temp.soCmnd = reader[0].ToString();
                    temp.gioiTinh = reader[1].ToString();
                    temp.diaChi = reader[2].ToString();
                    temp.email = reader[3].ToString();
                    string giathue = reader[4].ToString();
                    temp.donGia = control.xu_li_tien(giathue) + " VND";
                    temp.tienCoc = control.xu_li_tien(reader[5].ToString()) + " VND";
                    temp.ngayThue = DateTime.Parse(reader[6].ToString()).ToString("dd/MM/yyyy  hh:mm:ss tt");
                    temp.tongTien = control.xu_li_tien((int.Parse(giathue) * int.Parse(temp.soNgayThue)).ToString()) + " VND";
                    temp.tienPhat = "0";
                    temp.ngayTraThucTe = "Chưa trả";
                    temp.soCmnd_nv = reader[7].ToString();
                }
                reader.Close();
            }

            control_dash_board.thongtin.Clear();
            control_dash_board.thongtin.Add(temp);
            form_chi_tiet_hoa_don hoa_don = new form_chi_tiet_hoa_don();
            hoa_don.ShowDialog();
        }

        private void tao_hop_dong_button_Click(object sender, EventArgs e)
        {
            if(cccd_khach_combobox.Text != "" && bien_xe_combobox.Text != "" && dia_diem_combobox.Text != "")
        }
    }
}
