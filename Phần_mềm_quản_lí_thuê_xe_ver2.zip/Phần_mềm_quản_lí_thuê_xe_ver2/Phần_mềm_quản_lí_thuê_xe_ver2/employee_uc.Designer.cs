﻿namespace Phần_mềm_quản_lí_thuê_xe_ver2
{
    partial class employee_uc
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.guna2ShadowPanel1 = new Guna.UI2.WinForms.Guna2ShadowPanel();
            this.bang_nhan_vien = new System.Windows.Forms.DataGridView();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.tb_ngaysinh = new System.Windows.Forms.DateTimePicker();
            this.tb_diachi = new Guna.UI2.WinForms.Guna2TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btn_nu = new System.Windows.Forms.RadioButton();
            this.btn_nam = new System.Windows.Forms.RadioButton();
            this.tb_email = new Guna.UI2.WinForms.Guna2TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.tb_sdt = new Guna.UI2.WinForms.Guna2TextBox();
            this.tb_hoten = new Guna.UI2.WinForms.Guna2TextBox();
            this.tb_cmnd = new Guna.UI2.WinForms.Guna2TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.button_xoa_nv = new Guna.UI2.WinForms.Guna2Button();
            this.button_sua_nv = new Guna.UI2.WinForms.Guna2Button();
            this.them_nv_button = new Guna.UI2.WinForms.Guna2Button();
            this.guna2ShadowPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bang_nhan_vien)).BeginInit();
            this.tableLayoutPanel1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.panel4.SuspendLayout();
            this.SuspendLayout();
            // 
            // guna2ShadowPanel1
            // 
            this.guna2ShadowPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2ShadowPanel1.BackColor = System.Drawing.Color.Transparent;
            this.guna2ShadowPanel1.Controls.Add(this.bang_nhan_vien);
            this.guna2ShadowPanel1.FillColor = System.Drawing.Color.White;
            this.guna2ShadowPanel1.Location = new System.Drawing.Point(4, 233);
            this.guna2ShadowPanel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2ShadowPanel1.Name = "guna2ShadowPanel1";
            this.guna2ShadowPanel1.ShadowColor = System.Drawing.Color.Black;
            this.guna2ShadowPanel1.ShadowStyle = Guna.UI2.WinForms.Guna2ShadowPanel.ShadowMode.Dropped;
            this.guna2ShadowPanel1.Size = new System.Drawing.Size(1299, 411);
            this.guna2ShadowPanel1.TabIndex = 0;
            // 
            // bang_nhan_vien
            // 
            this.bang_nhan_vien.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.bang_nhan_vien.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.bang_nhan_vien.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.bang_nhan_vien.Location = new System.Drawing.Point(3, 2);
            this.bang_nhan_vien.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.bang_nhan_vien.Name = "bang_nhan_vien";
            this.bang_nhan_vien.RowHeadersWidth = 51;
            this.bang_nhan_vien.RowTemplate.Height = 24;
            this.bang_nhan_vien.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.bang_nhan_vien.Size = new System.Drawing.Size(1295, 390);
            this.bang_nhan_vien.TabIndex = 0;
            this.bang_nhan_vien.Click += new System.EventHandler(this.bang_nhan_vien_Click);
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel1.Controls.Add(this.panel3, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.panel2, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.panel1, 0, 0);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(5, 2);
            this.tableLayoutPanel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1299, 155);
            this.tableLayoutPanel1.TabIndex = 1;
            // 
            // panel3
            // 
            this.panel3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel3.Controls.Add(this.tb_ngaysinh);
            this.panel3.Controls.Add(this.tb_diachi);
            this.panel3.Controls.Add(this.label7);
            this.panel3.Controls.Add(this.label6);
            this.panel3.Location = new System.Drawing.Point(869, 2);
            this.panel3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(427, 151);
            this.panel3.TabIndex = 2;
            // 
            // tb_ngaysinh
            // 
            this.tb_ngaysinh.CustomFormat = "dd/MM/yyyy";
            this.tb_ngaysinh.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.tb_ngaysinh.Location = new System.Drawing.Point(103, 87);
            this.tb_ngaysinh.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tb_ngaysinh.Name = "tb_ngaysinh";
            this.tb_ngaysinh.Size = new System.Drawing.Size(285, 22);
            this.tb_ngaysinh.TabIndex = 5;
            this.tb_ngaysinh.Value = new System.DateTime(2024, 3, 23, 0, 0, 0, 0);
            // 
            // tb_diachi
            // 
            this.tb_diachi.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tb_diachi.Animated = true;
            this.tb_diachi.AutoRoundedCorners = true;
            this.tb_diachi.BorderRadius = 18;
            this.tb_diachi.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.tb_diachi.DefaultText = "";
            this.tb_diachi.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.tb_diachi.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.tb_diachi.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tb_diachi.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tb_diachi.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tb_diachi.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.tb_diachi.ForeColor = System.Drawing.Color.Black;
            this.tb_diachi.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tb_diachi.Location = new System.Drawing.Point(103, 15);
            this.tb_diachi.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tb_diachi.Name = "tb_diachi";
            this.tb_diachi.PasswordChar = '\0';
            this.tb_diachi.PlaceholderText = "";
            this.tb_diachi.SelectedText = "";
            this.tb_diachi.Size = new System.Drawing.Size(291, 38);
            this.tb_diachi.TabIndex = 4;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(21, 94);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(67, 16);
            this.label7.TabIndex = 1;
            this.label7.Text = "Ngày sinh";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(28, 28);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(47, 16);
            this.label6.TabIndex = 0;
            this.label6.Text = "Địa chỉ";
            // 
            // panel2
            // 
            this.panel2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel2.Controls.Add(this.btn_nu);
            this.panel2.Controls.Add(this.btn_nam);
            this.panel2.Controls.Add(this.tb_email);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Location = new System.Drawing.Point(436, 2);
            this.panel2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(427, 151);
            this.panel2.TabIndex = 1;
            // 
            // btn_nu
            // 
            this.btn_nu.AutoSize = true;
            this.btn_nu.Location = new System.Drawing.Point(219, 94);
            this.btn_nu.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_nu.Name = "btn_nu";
            this.btn_nu.Size = new System.Drawing.Size(45, 20);
            this.btn_nu.TabIndex = 6;
            this.btn_nu.TabStop = true;
            this.btn_nu.Text = "Nữ";
            this.btn_nu.UseVisualStyleBackColor = true;
            // 
            // btn_nam
            // 
            this.btn_nam.AutoSize = true;
            this.btn_nam.Location = new System.Drawing.Point(120, 94);
            this.btn_nam.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_nam.Name = "btn_nam";
            this.btn_nam.Size = new System.Drawing.Size(57, 20);
            this.btn_nam.TabIndex = 5;
            this.btn_nam.TabStop = true;
            this.btn_nam.Text = "Nam";
            this.btn_nam.UseVisualStyleBackColor = true;
            // 
            // tb_email
            // 
            this.tb_email.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tb_email.Animated = true;
            this.tb_email.AutoRoundedCorners = true;
            this.tb_email.BorderRadius = 18;
            this.tb_email.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.tb_email.DefaultText = "";
            this.tb_email.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.tb_email.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.tb_email.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tb_email.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tb_email.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tb_email.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.tb_email.ForeColor = System.Drawing.Color.Black;
            this.tb_email.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tb_email.Location = new System.Drawing.Point(95, 14);
            this.tb_email.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tb_email.Name = "tb_email";
            this.tb_email.PasswordChar = '\0';
            this.tb_email.PlaceholderText = "";
            this.tb_email.SelectedText = "";
            this.tb_email.Size = new System.Drawing.Size(291, 38);
            this.tb_email.TabIndex = 4;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(32, 95);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(54, 16);
            this.label5.TabIndex = 1;
            this.label5.Text = "Giới tính";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(32, 26);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(41, 16);
            this.label4.TabIndex = 0;
            this.label4.Text = "Email";
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.Controls.Add(this.tb_sdt);
            this.panel1.Controls.Add(this.tb_hoten);
            this.panel1.Controls.Add(this.tb_cmnd);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(3, 2);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(427, 151);
            this.panel1.TabIndex = 0;
            // 
            // tb_sdt
            // 
            this.tb_sdt.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tb_sdt.Animated = true;
            this.tb_sdt.AutoRoundedCorners = true;
            this.tb_sdt.BorderRadius = 18;
            this.tb_sdt.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.tb_sdt.DefaultText = "";
            this.tb_sdt.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.tb_sdt.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.tb_sdt.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tb_sdt.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tb_sdt.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tb_sdt.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.tb_sdt.ForeColor = System.Drawing.Color.Black;
            this.tb_sdt.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tb_sdt.Location = new System.Drawing.Point(115, 101);
            this.tb_sdt.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tb_sdt.Name = "tb_sdt";
            this.tb_sdt.PasswordChar = '\0';
            this.tb_sdt.PlaceholderText = "";
            this.tb_sdt.SelectedText = "";
            this.tb_sdt.Size = new System.Drawing.Size(291, 38);
            this.tb_sdt.TabIndex = 5;
            // 
            // tb_hoten
            // 
            this.tb_hoten.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tb_hoten.Animated = true;
            this.tb_hoten.AutoRoundedCorners = true;
            this.tb_hoten.BorderRadius = 18;
            this.tb_hoten.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.tb_hoten.DefaultText = "";
            this.tb_hoten.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.tb_hoten.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.tb_hoten.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tb_hoten.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tb_hoten.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tb_hoten.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.tb_hoten.ForeColor = System.Drawing.Color.Black;
            this.tb_hoten.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tb_hoten.Location = new System.Drawing.Point(115, 55);
            this.tb_hoten.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tb_hoten.Name = "tb_hoten";
            this.tb_hoten.PasswordChar = '\0';
            this.tb_hoten.PlaceholderText = "";
            this.tb_hoten.SelectedText = "";
            this.tb_hoten.Size = new System.Drawing.Size(291, 38);
            this.tb_hoten.TabIndex = 4;
            // 
            // tb_cmnd
            // 
            this.tb_cmnd.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tb_cmnd.Animated = true;
            this.tb_cmnd.AutoRoundedCorners = true;
            this.tb_cmnd.BorderRadius = 18;
            this.tb_cmnd.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.tb_cmnd.DefaultText = "";
            this.tb_cmnd.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.tb_cmnd.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.tb_cmnd.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tb_cmnd.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tb_cmnd.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tb_cmnd.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.tb_cmnd.ForeColor = System.Drawing.Color.Black;
            this.tb_cmnd.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tb_cmnd.Location = new System.Drawing.Point(115, 9);
            this.tb_cmnd.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tb_cmnd.Name = "tb_cmnd";
            this.tb_cmnd.PasswordChar = '\0';
            this.tb_cmnd.PlaceholderText = "";
            this.tb_cmnd.SelectedText = "";
            this.tb_cmnd.Size = new System.Drawing.Size(291, 38);
            this.tb_cmnd.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(16, 112);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(85, 16);
            this.label3.TabIndex = 2;
            this.label3.Text = "Số điện thoại";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(19, 69);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(52, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "Họ Tên";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(19, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(67, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Số CMND";
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel2.ColumnCount = 3;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 637F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Controls.Add(this.panel4, 1, 0);
            this.tableLayoutPanel2.Location = new System.Drawing.Point(5, 161);
            this.tableLayoutPanel2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 1;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(1299, 69);
            this.tableLayoutPanel2.TabIndex = 2;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.button_xoa_nv);
            this.panel4.Controls.Add(this.button_sua_nv);
            this.panel4.Controls.Add(this.them_nv_button);
            this.panel4.Location = new System.Drawing.Point(334, 2);
            this.panel4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(631, 63);
            this.panel4.TabIndex = 7;
            // 
            // button_xoa_nv
            // 
            this.button_xoa_nv.Animated = true;
            this.button_xoa_nv.AutoRoundedCorners = true;
            this.button_xoa_nv.BorderRadius = 22;
            this.button_xoa_nv.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.button_xoa_nv.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.button_xoa_nv.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.button_xoa_nv.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.button_xoa_nv.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.button_xoa_nv.ForeColor = System.Drawing.Color.White;
            this.button_xoa_nv.Location = new System.Drawing.Point(447, 9);
            this.button_xoa_nv.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button_xoa_nv.Name = "button_xoa_nv";
            this.button_xoa_nv.Size = new System.Drawing.Size(180, 46);
            this.button_xoa_nv.TabIndex = 6;
            this.button_xoa_nv.Text = "Xóa Nhân Viên";
            this.button_xoa_nv.Click += new System.EventHandler(this.button_xoa_nv_Click);
            // 
            // button_sua_nv
            // 
            this.button_sua_nv.Animated = true;
            this.button_sua_nv.AutoRoundedCorners = true;
            this.button_sua_nv.BorderRadius = 22;
            this.button_sua_nv.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.button_sua_nv.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.button_sua_nv.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.button_sua_nv.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.button_sua_nv.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.button_sua_nv.ForeColor = System.Drawing.Color.White;
            this.button_sua_nv.Location = new System.Drawing.Point(228, 9);
            this.button_sua_nv.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button_sua_nv.Name = "button_sua_nv";
            this.button_sua_nv.Size = new System.Drawing.Size(185, 46);
            this.button_sua_nv.TabIndex = 5;
            this.button_sua_nv.Text = "Sửa thông tin nhân viên";
            this.button_sua_nv.Click += new System.EventHandler(this.button_sua_nv_Click);
            // 
            // them_nv_button
            // 
            this.them_nv_button.Animated = true;
            this.them_nv_button.AutoRoundedCorners = true;
            this.them_nv_button.BorderRadius = 22;
            this.them_nv_button.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.them_nv_button.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.them_nv_button.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.them_nv_button.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.them_nv_button.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.them_nv_button.ForeColor = System.Drawing.Color.White;
            this.them_nv_button.Location = new System.Drawing.Point(9, 9);
            this.them_nv_button.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.them_nv_button.Name = "them_nv_button";
            this.them_nv_button.Size = new System.Drawing.Size(180, 46);
            this.them_nv_button.TabIndex = 4;
            this.them_nv_button.Text = "Thêm Nhân Viên";
            this.them_nv_button.Click += new System.EventHandler(this.them_nv_button_Click);
            // 
            // employee_uc
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.tableLayoutPanel2);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Controls.Add(this.guna2ShadowPanel1);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "employee_uc";
            this.Size = new System.Drawing.Size(1307, 647);
            this.Load += new System.EventHandler(this.employee_uc_Load);
            this.guna2ShadowPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.bang_nhan_vien)).EndInit();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private Guna.UI2.WinForms.Guna2ShadowPanel guna2ShadowPanel1;
        private System.Windows.Forms.DataGridView bang_nhan_vien;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private Guna.UI2.WinForms.Guna2TextBox tb_cmnd;
        private Guna.UI2.WinForms.Guna2TextBox tb_diachi;
        private Guna.UI2.WinForms.Guna2TextBox tb_email;
        private Guna.UI2.WinForms.Guna2TextBox tb_sdt;
        private Guna.UI2.WinForms.Guna2TextBox tb_hoten;
        private System.Windows.Forms.RadioButton btn_nu;
        private System.Windows.Forms.RadioButton btn_nam;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Panel panel4;
        private Guna.UI2.WinForms.Guna2Button button_xoa_nv;
        private Guna.UI2.WinForms.Guna2Button button_sua_nv;
        private Guna.UI2.WinForms.Guna2Button them_nv_button;
        private System.Windows.Forms.DateTimePicker tb_ngaysinh;
    }
}
