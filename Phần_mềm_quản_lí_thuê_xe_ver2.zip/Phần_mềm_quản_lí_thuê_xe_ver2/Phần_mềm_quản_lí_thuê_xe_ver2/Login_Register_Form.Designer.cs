﻿namespace Phần_mềm_quản_lí_thuê_xe_ver2
{
    partial class Login_Register_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Login_Register_Form));
            this.palette_login_register = new ComponentFactory.Krypton.Toolkit.KryptonPalette(this.components);
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.background_picture = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2Panel1 = new Guna.UI2.WinForms.Guna2Panel();
            this.login_panel = new Guna.UI2.WinForms.Guna2Panel();
            this.forgot_pass_label = new System.Windows.Forms.Label();
            this.change_register_button = new Guna.UI2.WinForms.Guna2GradientButton();
            this.label2 = new System.Windows.Forms.Label();
            this.guna2ToggleSwitch1 = new Guna.UI2.WinForms.Guna2ToggleSwitch();
            this.password_login_textbox = new Guna.UI2.WinForms.Guna2TextBox();
            this.user_login_textbox = new Guna.UI2.WinForms.Guna2TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.login_button = new Guna.UI2.WinForms.Guna2GradientButton();
            this.register_panel = new Guna.UI2.WinForms.Guna2Panel();
            this.verify_password_textbox = new Guna.UI2.WinForms.Guna2TextBox();
            this.password_register_textbox = new Guna.UI2.WinForms.Guna2TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.email_textbox = new Guna.UI2.WinForms.Guna2TextBox();
            this.username_register_textbox = new Guna.UI2.WinForms.Guna2TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.create_account_button = new Guna.UI2.WinForms.Guna2GradientButton();
            this.time_slide = new System.Windows.Forms.Timer(this.components);
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.background_picture)).BeginInit();
            this.guna2Panel1.SuspendLayout();
            this.login_panel.SuspendLayout();
            this.register_panel.SuspendLayout();
            this.SuspendLayout();
            // 
            // palette_login_register
            // 
            this.palette_login_register.ButtonSpecs.FormClose.Image = global::Phần_mềm_quản_lí_thuê_xe_ver2.Properties.Resources.close1;
            this.palette_login_register.ButtonSpecs.FormClose.ImageStates.ImagePressed = global::Phần_mềm_quản_lí_thuê_xe_ver2.Properties.Resources.close2;
            this.palette_login_register.ButtonSpecs.FormClose.ImageStates.ImageTracking = global::Phần_mềm_quản_lí_thuê_xe_ver2.Properties.Resources.close2;
            this.palette_login_register.ButtonSpecs.FormMax.Image = global::Phần_mềm_quản_lí_thuê_xe_ver2.Properties.Resources.max1;
            this.palette_login_register.ButtonSpecs.FormMax.ImageStates.ImagePressed = global::Phần_mềm_quản_lí_thuê_xe_ver2.Properties.Resources.max2;
            this.palette_login_register.ButtonSpecs.FormMax.ImageStates.ImageTracking = global::Phần_mềm_quản_lí_thuê_xe_ver2.Properties.Resources.max2;
            this.palette_login_register.ButtonSpecs.FormMin.Image = global::Phần_mềm_quản_lí_thuê_xe_ver2.Properties.Resources.mini1;
            this.palette_login_register.ButtonSpecs.FormMin.ImageStates.ImagePressed = global::Phần_mềm_quản_lí_thuê_xe_ver2.Properties.Resources.mini2;
            this.palette_login_register.ButtonSpecs.FormMin.ImageStates.ImageTracking = global::Phần_mềm_quản_lí_thuê_xe_ver2.Properties.Resources.mini2;
            this.palette_login_register.ButtonStyles.ButtonForm.StateNormal.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(254)))), ((int)(((byte)(254)))));
            this.palette_login_register.ButtonStyles.ButtonForm.StateNormal.Back.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(254)))), ((int)(((byte)(254)))));
            this.palette_login_register.ButtonStyles.ButtonForm.StateNormal.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.palette_login_register.ButtonStyles.ButtonForm.StateNormal.Border.Width = 0;
            this.palette_login_register.ButtonStyles.ButtonForm.StatePressed.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(254)))), ((int)(((byte)(254)))));
            this.palette_login_register.ButtonStyles.ButtonForm.StatePressed.Back.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(254)))), ((int)(((byte)(254)))));
            this.palette_login_register.ButtonStyles.ButtonForm.StatePressed.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.palette_login_register.ButtonStyles.ButtonForm.StatePressed.Border.Width = 0;
            this.palette_login_register.ButtonStyles.ButtonForm.StateTracking.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(254)))), ((int)(((byte)(254)))));
            this.palette_login_register.ButtonStyles.ButtonForm.StateTracking.Back.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(254)))), ((int)(((byte)(254)))));
            this.palette_login_register.ButtonStyles.ButtonForm.StateTracking.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.palette_login_register.ButtonStyles.ButtonForm.StateTracking.Border.Width = 0;
            this.palette_login_register.ButtonStyles.ButtonFormClose.StatePressed.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(254)))), ((int)(((byte)(254)))));
            this.palette_login_register.ButtonStyles.ButtonFormClose.StatePressed.Back.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(254)))), ((int)(((byte)(254)))));
            this.palette_login_register.ButtonStyles.ButtonFormClose.StatePressed.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.palette_login_register.ButtonStyles.ButtonFormClose.StatePressed.Border.Width = 0;
            this.palette_login_register.ButtonStyles.ButtonFormClose.StateTracking.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(254)))), ((int)(((byte)(254)))));
            this.palette_login_register.ButtonStyles.ButtonFormClose.StateTracking.Back.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(254)))), ((int)(((byte)(254)))));
            this.palette_login_register.ButtonStyles.ButtonFormClose.StateTracking.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.palette_login_register.ButtonStyles.ButtonFormClose.StateTracking.Border.Width = 0;
            this.palette_login_register.FormStyles.FormMain.StateCommon.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(254)))), ((int)(((byte)(254)))));
            this.palette_login_register.FormStyles.FormMain.StateCommon.Back.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(254)))), ((int)(((byte)(254)))));
            this.palette_login_register.FormStyles.FormMain.StateCommon.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.palette_login_register.FormStyles.FormMain.StateCommon.Border.GraphicsHint = ComponentFactory.Krypton.Toolkit.PaletteGraphicsHint.None;
            this.palette_login_register.FormStyles.FormMain.StateCommon.Border.Rounding = 12;
            this.palette_login_register.HeaderStyles.HeaderForm.StateCommon.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(254)))), ((int)(((byte)(254)))));
            this.palette_login_register.HeaderStyles.HeaderForm.StateCommon.Back.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(254)))), ((int)(((byte)(254)))));
            this.palette_login_register.HeaderStyles.HeaderForm.StateCommon.ButtonEdgeInset = 10;
            this.palette_login_register.HeaderStyles.HeaderForm.StateCommon.Content.Padding = new System.Windows.Forms.Padding(10, -1, -1, -1);
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Controls.Add(this.background_picture, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.guna2Panel1, 1, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1001, 474);
            this.tableLayoutPanel1.TabIndex = 1;
            // 
            // background_picture
            // 
            this.background_picture.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.background_picture.Image = global::Phần_mềm_quản_lí_thuê_xe_ver2.Properties.Resources.car_background1;
            this.background_picture.ImageRotate = 0F;
            this.background_picture.Location = new System.Drawing.Point(3, 2);
            this.background_picture.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.background_picture.Name = "background_picture";
            this.background_picture.Size = new System.Drawing.Size(494, 470);
            this.background_picture.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.background_picture.TabIndex = 0;
            this.background_picture.TabStop = false;
            // 
            // guna2Panel1
            // 
            this.guna2Panel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2Panel1.Controls.Add(this.login_panel);
            this.guna2Panel1.Controls.Add(this.register_panel);
            this.guna2Panel1.Location = new System.Drawing.Point(503, 2);
            this.guna2Panel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2Panel1.Name = "guna2Panel1";
            this.guna2Panel1.Size = new System.Drawing.Size(495, 470);
            this.guna2Panel1.TabIndex = 1;
            // 
            // login_panel
            // 
            this.login_panel.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.login_panel.Controls.Add(this.forgot_pass_label);
            this.login_panel.Controls.Add(this.change_register_button);
            this.login_panel.Controls.Add(this.label2);
            this.login_panel.Controls.Add(this.guna2ToggleSwitch1);
            this.login_panel.Controls.Add(this.password_login_textbox);
            this.login_panel.Controls.Add(this.user_login_textbox);
            this.login_panel.Controls.Add(this.label1);
            this.login_panel.Controls.Add(this.login_button);
            this.login_panel.Location = new System.Drawing.Point(71, 10);
            this.login_panel.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.login_panel.Name = "login_panel";
            this.login_panel.Size = new System.Drawing.Size(370, 448);
            this.login_panel.TabIndex = 9;
            // 
            // forgot_pass_label
            // 
            this.forgot_pass_label.Cursor = System.Windows.Forms.Cursors.Hand;
            this.forgot_pass_label.Font = new System.Drawing.Font("Source Code Pro", 7F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.forgot_pass_label.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.forgot_pass_label.Location = new System.Drawing.Point(192, 323);
            this.forgot_pass_label.Name = "forgot_pass_label";
            this.forgot_pass_label.Size = new System.Drawing.Size(148, 24);
            this.forgot_pass_label.TabIndex = 7;
            this.forgot_pass_label.Text = "Forgot password?";
            this.forgot_pass_label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // change_register_button
            // 
            this.change_register_button.Animated = true;
            this.change_register_button.AutoRoundedCorners = true;
            this.change_register_button.BorderRadius = 26;
            this.change_register_button.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.change_register_button.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.change_register_button.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.change_register_button.DisabledState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.change_register_button.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.change_register_button.FillColor = System.Drawing.Color.Transparent;
            this.change_register_button.FillColor2 = System.Drawing.Color.Transparent;
            this.change_register_button.Font = new System.Drawing.Font("Segoe UI Black", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.change_register_button.ForeColor = System.Drawing.Color.DimGray;
            this.change_register_button.Image = global::Phần_mềm_quản_lí_thuê_xe_ver2.Properties.Resources.arrow_icon1;
            this.change_register_button.ImageAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.change_register_button.ImageSize = new System.Drawing.Size(37, 37);
            this.change_register_button.Location = new System.Drawing.Point(35, 350);
            this.change_register_button.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.change_register_button.Name = "change_register_button";
            this.change_register_button.Size = new System.Drawing.Size(307, 54);
            this.change_register_button.TabIndex = 6;
            this.change_register_button.Text = "Create Account";
            this.change_register_button.Click += new System.EventHandler(this.switch_login_register_panel);
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Source Code Pro", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label2.Location = new System.Drawing.Point(84, 220);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(132, 22);
            this.label2.TabIndex = 5;
            this.label2.Text = "Remember me";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // guna2ToggleSwitch1
            // 
            this.guna2ToggleSwitch1.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2ToggleSwitch1.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2ToggleSwitch1.CheckedState.InnerBorderColor = System.Drawing.Color.White;
            this.guna2ToggleSwitch1.CheckedState.InnerColor = System.Drawing.Color.White;
            this.guna2ToggleSwitch1.Location = new System.Drawing.Point(36, 221);
            this.guna2ToggleSwitch1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2ToggleSwitch1.Name = "guna2ToggleSwitch1";
            this.guna2ToggleSwitch1.Size = new System.Drawing.Size(46, 22);
            this.guna2ToggleSwitch1.TabIndex = 4;
            this.guna2ToggleSwitch1.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2ToggleSwitch1.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2ToggleSwitch1.UncheckedState.InnerBorderColor = System.Drawing.Color.White;
            this.guna2ToggleSwitch1.UncheckedState.InnerColor = System.Drawing.Color.White;
            // 
            // password_login_textbox
            // 
            this.password_login_textbox.Animated = true;
            this.password_login_textbox.AutoRoundedCorners = true;
            this.password_login_textbox.BorderColor = System.Drawing.Color.Black;
            this.password_login_textbox.BorderRadius = 19;
            this.password_login_textbox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.password_login_textbox.DefaultText = "";
            this.password_login_textbox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.password_login_textbox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.password_login_textbox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.password_login_textbox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.password_login_textbox.FillColor = System.Drawing.Color.Gainsboro;
            this.password_login_textbox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.password_login_textbox.Font = new System.Drawing.Font("Source Code Pro SemiBold", 9F, System.Drawing.FontStyle.Bold);
            this.password_login_textbox.ForeColor = System.Drawing.Color.Black;
            this.password_login_textbox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.password_login_textbox.IconLeft = global::Phần_mềm_quản_lí_thuê_xe_ver2.Properties.Resources.password_icon;
            this.password_login_textbox.Location = new System.Drawing.Point(35, 169);
            this.password_login_textbox.Margin = new System.Windows.Forms.Padding(4);
            this.password_login_textbox.Name = "password_login_textbox";
            this.password_login_textbox.PasswordChar = '*';
            this.password_login_textbox.PlaceholderForeColor = System.Drawing.Color.Gray;
            this.password_login_textbox.PlaceholderText = "Password";
            this.password_login_textbox.SelectedText = "";
            this.password_login_textbox.Size = new System.Drawing.Size(307, 40);
            this.password_login_textbox.TabIndex = 3;
            // 
            // user_login_textbox
            // 
            this.user_login_textbox.Animated = true;
            this.user_login_textbox.AutoRoundedCorners = true;
            this.user_login_textbox.BorderColor = System.Drawing.Color.Black;
            this.user_login_textbox.BorderRadius = 19;
            this.user_login_textbox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.user_login_textbox.DefaultText = "";
            this.user_login_textbox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.user_login_textbox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.user_login_textbox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.user_login_textbox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.user_login_textbox.FillColor = System.Drawing.Color.Gainsboro;
            this.user_login_textbox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.user_login_textbox.Font = new System.Drawing.Font("Source Code Pro SemiBold", 9F, System.Drawing.FontStyle.Bold);
            this.user_login_textbox.ForeColor = System.Drawing.Color.Black;
            this.user_login_textbox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.user_login_textbox.IconLeft = global::Phần_mềm_quản_lí_thuê_xe_ver2.Properties.Resources.username;
            this.user_login_textbox.Location = new System.Drawing.Point(35, 98);
            this.user_login_textbox.Margin = new System.Windows.Forms.Padding(4);
            this.user_login_textbox.Name = "user_login_textbox";
            this.user_login_textbox.PasswordChar = '\0';
            this.user_login_textbox.PlaceholderForeColor = System.Drawing.Color.Gray;
            this.user_login_textbox.PlaceholderText = "Username";
            this.user_login_textbox.SelectedText = "";
            this.user_login_textbox.Size = new System.Drawing.Size(307, 40);
            this.user_login_textbox.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Segoe UI Black", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(97, 32);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(182, 34);
            this.label1.TabIndex = 1;
            this.label1.Text = "USER LOGIN";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // login_button
            // 
            this.login_button.Animated = true;
            this.login_button.AutoRoundedCorners = true;
            this.login_button.BorderRadius = 25;
            this.login_button.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.login_button.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.login_button.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.login_button.DisabledState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.login_button.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.login_button.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(208)))), ((int)(((byte)(125)))));
            this.login_button.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(9)))), ((int)(((byte)(214)))), ((int)(((byte)(213)))));
            this.login_button.Font = new System.Drawing.Font("Segoe UI Black", 11F, System.Drawing.FontStyle.Bold);
            this.login_button.ForeColor = System.Drawing.Color.White;
            this.login_button.Location = new System.Drawing.Point(35, 269);
            this.login_button.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.login_button.Name = "login_button";
            this.login_button.Size = new System.Drawing.Size(305, 52);
            this.login_button.TabIndex = 0;
            this.login_button.Text = "LOGIN";
            this.login_button.Click += new System.EventHandler(this.login_button_Click);
            // 
            // register_panel
            // 
            this.register_panel.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.register_panel.Controls.Add(this.verify_password_textbox);
            this.register_panel.Controls.Add(this.password_register_textbox);
            this.register_panel.Controls.Add(this.label4);
            this.register_panel.Controls.Add(this.email_textbox);
            this.register_panel.Controls.Add(this.username_register_textbox);
            this.register_panel.Controls.Add(this.label6);
            this.register_panel.Controls.Add(this.create_account_button);
            this.register_panel.Location = new System.Drawing.Point(72, 9);
            this.register_panel.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.register_panel.Name = "register_panel";
            this.register_panel.Size = new System.Drawing.Size(370, 447);
            this.register_panel.TabIndex = 8;
            this.register_panel.Visible = false;
            // 
            // verify_password_textbox
            // 
            this.verify_password_textbox.Animated = true;
            this.verify_password_textbox.AutoRoundedCorners = true;
            this.verify_password_textbox.BorderColor = System.Drawing.Color.Black;
            this.verify_password_textbox.BorderRadius = 19;
            this.verify_password_textbox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.verify_password_textbox.DefaultText = "";
            this.verify_password_textbox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.verify_password_textbox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.verify_password_textbox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.verify_password_textbox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.verify_password_textbox.FillColor = System.Drawing.Color.Gainsboro;
            this.verify_password_textbox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.verify_password_textbox.Font = new System.Drawing.Font("Source Code Pro SemiBold", 9F, System.Drawing.FontStyle.Bold);
            this.verify_password_textbox.ForeColor = System.Drawing.Color.Black;
            this.verify_password_textbox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.verify_password_textbox.IconLeft = global::Phần_mềm_quản_lí_thuê_xe_ver2.Properties.Resources.password_icon;
            this.verify_password_textbox.Location = new System.Drawing.Point(33, 261);
            this.verify_password_textbox.Margin = new System.Windows.Forms.Padding(4);
            this.verify_password_textbox.Name = "verify_password_textbox";
            this.verify_password_textbox.PasswordChar = '*';
            this.verify_password_textbox.PlaceholderForeColor = System.Drawing.Color.Gray;
            this.verify_password_textbox.PlaceholderText = "Verify Password";
            this.verify_password_textbox.SelectedText = "";
            this.verify_password_textbox.Size = new System.Drawing.Size(307, 40);
            this.verify_password_textbox.TabIndex = 9;
            this.verify_password_textbox.TextChanged += new System.EventHandler(this.verify_password_textbox_TextChanged);
            // 
            // password_register_textbox
            // 
            this.password_register_textbox.Animated = true;
            this.password_register_textbox.AutoRoundedCorners = true;
            this.password_register_textbox.BorderColor = System.Drawing.Color.Black;
            this.password_register_textbox.BorderRadius = 19;
            this.password_register_textbox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.password_register_textbox.DefaultText = "";
            this.password_register_textbox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.password_register_textbox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.password_register_textbox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.password_register_textbox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.password_register_textbox.FillColor = System.Drawing.Color.Gainsboro;
            this.password_register_textbox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.password_register_textbox.Font = new System.Drawing.Font("Source Code Pro SemiBold", 9F, System.Drawing.FontStyle.Bold);
            this.password_register_textbox.ForeColor = System.Drawing.Color.Black;
            this.password_register_textbox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.password_register_textbox.IconLeft = global::Phần_mềm_quản_lí_thuê_xe_ver2.Properties.Resources.password_icon;
            this.password_register_textbox.Location = new System.Drawing.Point(33, 202);
            this.password_register_textbox.Margin = new System.Windows.Forms.Padding(4);
            this.password_register_textbox.Name = "password_register_textbox";
            this.password_register_textbox.PasswordChar = '*';
            this.password_register_textbox.PlaceholderForeColor = System.Drawing.Color.Gray;
            this.password_register_textbox.PlaceholderText = "Password";
            this.password_register_textbox.SelectedText = "";
            this.password_register_textbox.Size = new System.Drawing.Size(307, 40);
            this.password_register_textbox.TabIndex = 8;
            this.password_register_textbox.TextChanged += new System.EventHandler(this.password_register_textbox_TextChanged);
            // 
            // label4
            // 
            this.label4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label4.Font = new System.Drawing.Font("Source Code Pro", 7F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label4.Location = new System.Drawing.Point(260, 380);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(80, 26);
            this.label4.TabIndex = 7;
            this.label4.Text = "Login";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label4.Click += new System.EventHandler(this.switch_login_register_panel);
            // 
            // email_textbox
            // 
            this.email_textbox.Animated = true;
            this.email_textbox.AutoRoundedCorners = true;
            this.email_textbox.BorderColor = System.Drawing.Color.Black;
            this.email_textbox.BorderRadius = 19;
            this.email_textbox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.email_textbox.DefaultText = "";
            this.email_textbox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.email_textbox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.email_textbox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.email_textbox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.email_textbox.FillColor = System.Drawing.Color.Gainsboro;
            this.email_textbox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.email_textbox.Font = new System.Drawing.Font("Source Code Pro SemiBold", 9F, System.Drawing.FontStyle.Bold);
            this.email_textbox.ForeColor = System.Drawing.Color.Black;
            this.email_textbox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.email_textbox.IconLeft = global::Phần_mềm_quản_lí_thuê_xe_ver2.Properties.Resources.email_icon;
            this.email_textbox.Location = new System.Drawing.Point(33, 144);
            this.email_textbox.Margin = new System.Windows.Forms.Padding(4);
            this.email_textbox.Name = "email_textbox";
            this.email_textbox.PasswordChar = '\0';
            this.email_textbox.PlaceholderForeColor = System.Drawing.Color.Gray;
            this.email_textbox.PlaceholderText = "Email";
            this.email_textbox.SelectedText = "";
            this.email_textbox.Size = new System.Drawing.Size(307, 40);
            this.email_textbox.TabIndex = 3;
            this.email_textbox.TextChanged += new System.EventHandler(this.email_textbox_TextChanged);
            // 
            // username_register_textbox
            // 
            this.username_register_textbox.Animated = true;
            this.username_register_textbox.AutoRoundedCorners = true;
            this.username_register_textbox.BorderColor = System.Drawing.Color.Black;
            this.username_register_textbox.BorderRadius = 19;
            this.username_register_textbox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.username_register_textbox.DefaultText = "";
            this.username_register_textbox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.username_register_textbox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.username_register_textbox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.username_register_textbox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.username_register_textbox.FillColor = System.Drawing.Color.Gainsboro;
            this.username_register_textbox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.username_register_textbox.Font = new System.Drawing.Font("Source Code Pro SemiBold", 9F, System.Drawing.FontStyle.Bold);
            this.username_register_textbox.ForeColor = System.Drawing.Color.Black;
            this.username_register_textbox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.username_register_textbox.IconLeft = global::Phần_mềm_quản_lí_thuê_xe_ver2.Properties.Resources.username;
            this.username_register_textbox.Location = new System.Drawing.Point(33, 84);
            this.username_register_textbox.Margin = new System.Windows.Forms.Padding(4);
            this.username_register_textbox.Name = "username_register_textbox";
            this.username_register_textbox.PasswordChar = '\0';
            this.username_register_textbox.PlaceholderForeColor = System.Drawing.Color.Gray;
            this.username_register_textbox.PlaceholderText = "Username";
            this.username_register_textbox.SelectedText = "";
            this.username_register_textbox.Size = new System.Drawing.Size(307, 40);
            this.username_register_textbox.TabIndex = 2;
            this.username_register_textbox.TextChanged += new System.EventHandler(this.username_register_textbox_TextChanged);
            // 
            // label6
            // 
            this.label6.Font = new System.Drawing.Font("Segoe UI Black", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(97, 32);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(182, 34);
            this.label6.TabIndex = 1;
            this.label6.Text = "REGISTER";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // create_account_button
            // 
            this.create_account_button.Animated = true;
            this.create_account_button.AutoRoundedCorners = true;
            this.create_account_button.BorderRadius = 26;
            this.create_account_button.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.create_account_button.DisabledState.CustomBorderColor = System.Drawing.Color.Snow;
            this.create_account_button.DisabledState.FillColor = System.Drawing.Color.Silver;
            this.create_account_button.DisabledState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.create_account_button.DisabledState.ForeColor = System.Drawing.Color.Black;
            this.create_account_button.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(208)))), ((int)(((byte)(125)))));
            this.create_account_button.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(9)))), ((int)(((byte)(214)))), ((int)(((byte)(213)))));
            this.create_account_button.Font = new System.Drawing.Font("Segoe UI Black", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.create_account_button.ForeColor = System.Drawing.Color.White;
            this.create_account_button.Location = new System.Drawing.Point(33, 326);
            this.create_account_button.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.create_account_button.Name = "create_account_button";
            this.create_account_button.Size = new System.Drawing.Size(301, 54);
            this.create_account_button.TabIndex = 0;
            this.create_account_button.Text = "CREATE ACCOUNT";
            this.create_account_button.Click += new System.EventHandler(this.create_account_button_Click);
            // 
            // time_slide
            // 
            this.time_slide.Interval = 5000;
            this.time_slide.Tick += new System.EventHandler(this.time_slide_Tick);
            // 
            // Login_Register_Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(254)))), ((int)(((byte)(254)))));
            this.ClientSize = new System.Drawing.Size(1001, 474);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.MaximumSize = new System.Drawing.Size(1019, 521);
            this.MinimumSize = new System.Drawing.Size(1019, 521);
            this.Name = "Login_Register_Form";
            this.Palette = this.palette_login_register;
            this.PaletteMode = ComponentFactory.Krypton.Toolkit.PaletteMode.Custom;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.StateActive.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.StateActive.Border.Rounding = 15;
            this.StateCommon.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.StateCommon.Border.Rounding = 15;
            this.StateInactive.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.StateInactive.Border.Rounding = 15;
            this.Text = "Login_Register_Form";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Login_Register_Form_FormClosed);
            this.Load += new System.EventHandler(this.Login_Register_Form_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.background_picture)).EndInit();
            this.guna2Panel1.ResumeLayout(false);
            this.login_panel.ResumeLayout(false);
            this.register_panel.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private ComponentFactory.Krypton.Toolkit.KryptonPalette palette_login_register;
        private Guna.UI2.WinForms.Guna2PictureBox background_picture;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel1;
        private Guna.UI2.WinForms.Guna2Panel register_panel;
        private Guna.UI2.WinForms.Guna2TextBox verify_password_textbox;
        private Guna.UI2.WinForms.Guna2TextBox password_register_textbox;
        private System.Windows.Forms.Label label4;
        private Guna.UI2.WinForms.Guna2TextBox email_textbox;
        private Guna.UI2.WinForms.Guna2TextBox username_register_textbox;
        private System.Windows.Forms.Label label6;
        private Guna.UI2.WinForms.Guna2GradientButton create_account_button;
        private Guna.UI2.WinForms.Guna2Panel login_panel;
        private System.Windows.Forms.Label forgot_pass_label;
        private Guna.UI2.WinForms.Guna2GradientButton change_register_button;
        private System.Windows.Forms.Label label2;
        private Guna.UI2.WinForms.Guna2ToggleSwitch guna2ToggleSwitch1;
        private Guna.UI2.WinForms.Guna2TextBox password_login_textbox;
        private Guna.UI2.WinForms.Guna2TextBox user_login_textbox;
        private System.Windows.Forms.Label label1;
        private Guna.UI2.WinForms.Guna2GradientButton login_button;
        private System.Windows.Forms.Timer time_slide;
    }
}