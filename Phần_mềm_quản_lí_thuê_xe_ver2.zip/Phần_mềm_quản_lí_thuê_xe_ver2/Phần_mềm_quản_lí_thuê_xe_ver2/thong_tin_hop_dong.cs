﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Phần_mềm_quản_lí_thuê_xe_ver2
{
    public class thong_tin_hop_dong
    {
        public string hoTenKhach { get; set; }
        public string soCmnd { get; set; }
        public string gioiTinh { get; set; }
        public string diaChi { get; set; }
        public string sdt { get; set; }
        public string email { get; set; }
        /// <summary>
        /// /////
        /// </summary>
        public string tenXe { get; set; }
        public string soCho { get; set; }
        public string bienSo { get; set; }
        public string ngayThue { get; set; }
        public string soNgayThue { get; set; }
        public string diaDiemThueXe { get; set; }  
        public string ngayTraDuKien { get; set; }
        public string ngayTraThucTe {  get; set; } 
        public string donGia { get; set; }
        public string tienCoc { get; set; }
        public string tienPhat { get; set; }
        public string tongTien { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string hoTenNhanVien { get; set; }
        public string soCmnd_nv { get; set; }

    }
}
