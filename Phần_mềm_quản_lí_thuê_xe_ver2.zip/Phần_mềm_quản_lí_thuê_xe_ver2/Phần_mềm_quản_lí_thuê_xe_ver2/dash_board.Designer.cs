﻿namespace Phần_mềm_quản_lí_thuê_xe_ver2
{
    partial class dash_board
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(dash_board));
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.button1 = new System.Windows.Forms.Button();
            this.guna2Panel3 = new Guna.UI2.WinForms.Guna2Panel();
            this.reports_button = new Guna.UI2.WinForms.Guna2Button();
            this.home_button = new Guna.UI2.WinForms.Guna2Button();
            this.imgslide = new Guna.UI2.WinForms.Guna2PictureBox();
            this.employee_button = new Guna.UI2.WinForms.Guna2Button();
            this.customers_button = new Guna.UI2.WinForms.Guna2Button();
            this.suppliers_button = new Guna.UI2.WinForms.Guna2Button();
            this.vehicles_button = new Guna.UI2.WinForms.Guna2Button();
            this.main_center = new Guna.UI2.WinForms.Guna2CustomGradientPanel();
            this.palette_dash_board = new ComponentFactory.Krypton.Toolkit.KryptonPalette(this.components);
            this.tableLayoutPanel1.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.guna2Panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.imgslide)).BeginInit();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.BackColor = System.Drawing.Color.Transparent;
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 112F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel2, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.main_center, 1, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Margin = new System.Windows.Forms.Padding(2);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1543, 872);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel2.ColumnCount = 1;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.Controls.Add(this.button1, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.guna2Panel3, 0, 1);
            this.tableLayoutPanel2.Location = new System.Drawing.Point(2, 2);
            this.tableLayoutPanel2.Margin = new System.Windows.Forms.Padding(2);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 3;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 631F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(108, 868);
            this.tableLayoutPanel2.TabIndex = 2;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(2, 2);
            this.button1.Margin = new System.Windows.Forms.Padding(2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(62, 56);
            this.button1.TabIndex = 0;
            this.button1.Text = "back";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // guna2Panel3
            // 
            this.guna2Panel3.BackColor = System.Drawing.Color.White;
            this.guna2Panel3.BorderRadius = 20;
            this.guna2Panel3.Controls.Add(this.reports_button);
            this.guna2Panel3.Controls.Add(this.home_button);
            this.guna2Panel3.Controls.Add(this.imgslide);
            this.guna2Panel3.Controls.Add(this.employee_button);
            this.guna2Panel3.Controls.Add(this.customers_button);
            this.guna2Panel3.Controls.Add(this.suppliers_button);
            this.guna2Panel3.Controls.Add(this.vehicles_button);
            this.guna2Panel3.FillColor = System.Drawing.Color.Black;
            this.guna2Panel3.Location = new System.Drawing.Point(2, 120);
            this.guna2Panel3.Margin = new System.Windows.Forms.Padding(2);
            this.guna2Panel3.Name = "guna2Panel3";
            this.guna2Panel3.Size = new System.Drawing.Size(102, 627);
            this.guna2Panel3.TabIndex = 3;
            // 
            // reports_button
            // 
            this.reports_button.Animated = true;
            this.reports_button.BackColor = System.Drawing.Color.Transparent;
            this.reports_button.BorderRadius = 23;
            this.reports_button.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.RadioButton;
            this.reports_button.CheckedState.FillColor = System.Drawing.Color.White;
            this.reports_button.CustomImages.HoveredImage = global::Phần_mềm_quản_lí_thuê_xe_ver2.Properties.Resources.bao_cao_hover;
            this.reports_button.CustomImages.Image = global::Phần_mềm_quản_lí_thuê_xe_ver2.Properties.Resources.bao_cao;
            this.reports_button.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.reports_button.CustomImages.ImageOffset = new System.Drawing.Point(0, -10);
            this.reports_button.CustomImages.ImageSize = new System.Drawing.Size(28, 28);
            this.reports_button.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.reports_button.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.reports_button.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.reports_button.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.reports_button.FillColor = System.Drawing.Color.Transparent;
            this.reports_button.Font = new System.Drawing.Font("Segoe UI", 7F);
            this.reports_button.ForeColor = System.Drawing.Color.Transparent;
            this.reports_button.HoverState.FillColor = System.Drawing.Color.Transparent;
            this.reports_button.HoverState.Font = new System.Drawing.Font("Segoe UI", 7F, System.Drawing.FontStyle.Bold);
            this.reports_button.HoverState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(156)))), ((int)(((byte)(189)))));
            this.reports_button.Location = new System.Drawing.Point(8, 519);
            this.reports_button.Margin = new System.Windows.Forms.Padding(2);
            this.reports_button.Name = "reports_button";
            this.reports_button.ShadowDecoration.BorderRadius = 10;
            this.reports_button.ShadowDecoration.Color = System.Drawing.Color.DarkGray;
            this.reports_button.ShadowDecoration.Shadow = new System.Windows.Forms.Padding(0, 0, 10, 10);
            this.reports_button.Size = new System.Drawing.Size(86, 86);
            this.reports_button.TabIndex = 7;
            this.reports_button.Text = "Reports";
            this.reports_button.TextOffset = new System.Drawing.Point(0, 20);
            this.reports_button.UseTransparentBackground = true;
            this.reports_button.CheckedChanged += new System.EventHandler(this.button_CheckedChanged);
            this.reports_button.Click += new System.EventHandler(this.reports_button_Click);
            // 
            // home_button
            // 
            this.home_button.Animated = true;
            this.home_button.BackColor = System.Drawing.Color.Transparent;
            this.home_button.BorderRadius = 23;
            this.home_button.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.RadioButton;
            this.home_button.Checked = true;
            this.home_button.CheckedState.FillColor = System.Drawing.Color.White;
            this.home_button.CustomImages.HoveredImage = global::Phần_mềm_quản_lí_thuê_xe_ver2.Properties.Resources.home_hover;
            this.home_button.CustomImages.Image = global::Phần_mềm_quản_lí_thuê_xe_ver2.Properties.Resources.home;
            this.home_button.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.home_button.CustomImages.ImageOffset = new System.Drawing.Point(0, -10);
            this.home_button.CustomImages.ImageSize = new System.Drawing.Size(28, 28);
            this.home_button.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.home_button.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.home_button.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.home_button.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.home_button.FillColor = System.Drawing.Color.Transparent;
            this.home_button.Font = new System.Drawing.Font("Segoe UI", 7F);
            this.home_button.ForeColor = System.Drawing.Color.Transparent;
            this.home_button.HoverState.BorderColor = System.Drawing.Color.Black;
            this.home_button.HoverState.CustomBorderColor = System.Drawing.Color.Black;
            this.home_button.HoverState.FillColor = System.Drawing.Color.Transparent;
            this.home_button.HoverState.Font = new System.Drawing.Font("Segoe UI", 7F, System.Drawing.FontStyle.Bold);
            this.home_button.HoverState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(156)))), ((int)(((byte)(189)))));
            this.home_button.Location = new System.Drawing.Point(8, 19);
            this.home_button.Margin = new System.Windows.Forms.Padding(2);
            this.home_button.Name = "home_button";
            this.home_button.ShadowDecoration.BorderRadius = 10;
            this.home_button.ShadowDecoration.Color = System.Drawing.Color.DarkGray;
            this.home_button.ShadowDecoration.Shadow = new System.Windows.Forms.Padding(0, 0, 10, 10);
            this.home_button.Size = new System.Drawing.Size(86, 86);
            this.home_button.TabIndex = 4;
            this.home_button.Text = "Home";
            this.home_button.TextOffset = new System.Drawing.Point(0, 20);
            this.home_button.UseTransparentBackground = true;
            this.home_button.CheckedChanged += new System.EventHandler(this.button_CheckedChanged);
            this.home_button.Click += new System.EventHandler(this.home_button_Click);
            // 
            // imgslide
            // 
            this.imgslide.BackColor = System.Drawing.Color.Transparent;
            this.imgslide.Image = global::Phần_mềm_quản_lí_thuê_xe_ver2.Properties.Resources.slide;
            this.imgslide.ImageRotate = 0F;
            this.imgslide.Location = new System.Drawing.Point(68, -5);
            this.imgslide.Margin = new System.Windows.Forms.Padding(2);
            this.imgslide.Name = "imgslide";
            this.imgslide.Size = new System.Drawing.Size(39, 135);
            this.imgslide.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.imgslide.TabIndex = 1;
            this.imgslide.TabStop = false;
            // 
            // employee_button
            // 
            this.employee_button.Animated = true;
            this.employee_button.BackColor = System.Drawing.Color.Transparent;
            this.employee_button.BorderRadius = 23;
            this.employee_button.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.RadioButton;
            this.employee_button.CheckedState.FillColor = System.Drawing.Color.White;
            this.employee_button.CustomImages.HoveredImage = ((System.Drawing.Image)(resources.GetObject("resource.HoveredImage")));
            this.employee_button.CustomImages.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image")));
            this.employee_button.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.employee_button.CustomImages.ImageOffset = new System.Drawing.Point(0, -10);
            this.employee_button.CustomImages.ImageSize = new System.Drawing.Size(30, 30);
            this.employee_button.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.employee_button.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.employee_button.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.employee_button.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.employee_button.FillColor = System.Drawing.Color.Transparent;
            this.employee_button.Font = new System.Drawing.Font("Segoe UI", 7F);
            this.employee_button.ForeColor = System.Drawing.Color.Transparent;
            this.employee_button.HoverState.FillColor = System.Drawing.Color.Transparent;
            this.employee_button.HoverState.Font = new System.Drawing.Font("Segoe UI", 7F, System.Drawing.FontStyle.Bold);
            this.employee_button.HoverState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(156)))), ((int)(((byte)(189)))));
            this.employee_button.Location = new System.Drawing.Point(8, 419);
            this.employee_button.Margin = new System.Windows.Forms.Padding(2);
            this.employee_button.Name = "employee_button";
            this.employee_button.ShadowDecoration.BorderRadius = 10;
            this.employee_button.ShadowDecoration.Color = System.Drawing.Color.DarkGray;
            this.employee_button.ShadowDecoration.Shadow = new System.Windows.Forms.Padding(0, 0, 10, 10);
            this.employee_button.Size = new System.Drawing.Size(86, 86);
            this.employee_button.TabIndex = 6;
            this.employee_button.Text = "Employee";
            this.employee_button.TextOffset = new System.Drawing.Point(0, 20);
            this.employee_button.UseTransparentBackground = true;
            this.employee_button.CheckedChanged += new System.EventHandler(this.button_CheckedChanged);
            this.employee_button.Click += new System.EventHandler(this.Employee_button_Click);
            // 
            // customers_button
            // 
            this.customers_button.Animated = true;
            this.customers_button.BackColor = System.Drawing.Color.Transparent;
            this.customers_button.BorderRadius = 23;
            this.customers_button.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.RadioButton;
            this.customers_button.CheckedState.FillColor = System.Drawing.Color.White;
            this.customers_button.CustomImages.HoveredImage = global::Phần_mềm_quản_lí_thuê_xe_ver2.Properties.Resources.khach_hang_hover;
            this.customers_button.CustomImages.Image = global::Phần_mềm_quản_lí_thuê_xe_ver2.Properties.Resources.khach_hang;
            this.customers_button.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.customers_button.CustomImages.ImageOffset = new System.Drawing.Point(0, -10);
            this.customers_button.CustomImages.ImageSize = new System.Drawing.Size(28, 28);
            this.customers_button.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.customers_button.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.customers_button.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.customers_button.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.customers_button.FillColor = System.Drawing.Color.Transparent;
            this.customers_button.Font = new System.Drawing.Font("Segoe UI", 7F);
            this.customers_button.ForeColor = System.Drawing.Color.Transparent;
            this.customers_button.HoverState.FillColor = System.Drawing.Color.Transparent;
            this.customers_button.HoverState.Font = new System.Drawing.Font("Segoe UI", 7F, System.Drawing.FontStyle.Bold);
            this.customers_button.HoverState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(156)))), ((int)(((byte)(189)))));
            this.customers_button.Location = new System.Drawing.Point(8, 119);
            this.customers_button.Margin = new System.Windows.Forms.Padding(2);
            this.customers_button.Name = "customers_button";
            this.customers_button.ShadowDecoration.BorderRadius = 10;
            this.customers_button.ShadowDecoration.Color = System.Drawing.Color.DarkGray;
            this.customers_button.ShadowDecoration.Shadow = new System.Windows.Forms.Padding(0, 0, 10, 10);
            this.customers_button.Size = new System.Drawing.Size(86, 86);
            this.customers_button.TabIndex = 2;
            this.customers_button.Text = "Customer";
            this.customers_button.TextOffset = new System.Drawing.Point(0, 20);
            this.customers_button.UseTransparentBackground = true;
            this.customers_button.CheckedChanged += new System.EventHandler(this.button_CheckedChanged);
            this.customers_button.Click += new System.EventHandler(this.customers_button_Click);
            // 
            // suppliers_button
            // 
            this.suppliers_button.Animated = true;
            this.suppliers_button.BackColor = System.Drawing.Color.Transparent;
            this.suppliers_button.BorderRadius = 23;
            this.suppliers_button.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.RadioButton;
            this.suppliers_button.CheckedState.FillColor = System.Drawing.Color.White;
            this.suppliers_button.CustomImages.HoveredImage = global::Phần_mềm_quản_lí_thuê_xe_ver2.Properties.Resources.nha_cung_cap_hover;
            this.suppliers_button.CustomImages.Image = global::Phần_mềm_quản_lí_thuê_xe_ver2.Properties.Resources.nha_cung_cap;
            this.suppliers_button.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.suppliers_button.CustomImages.ImageOffset = new System.Drawing.Point(0, -10);
            this.suppliers_button.CustomImages.ImageSize = new System.Drawing.Size(28, 28);
            this.suppliers_button.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.suppliers_button.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.suppliers_button.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.suppliers_button.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.suppliers_button.FillColor = System.Drawing.Color.Transparent;
            this.suppliers_button.Font = new System.Drawing.Font("Segoe UI", 7F);
            this.suppliers_button.ForeColor = System.Drawing.Color.Transparent;
            this.suppliers_button.HoverState.FillColor = System.Drawing.Color.Transparent;
            this.suppliers_button.HoverState.Font = new System.Drawing.Font("Segoe UI", 7F, System.Drawing.FontStyle.Bold);
            this.suppliers_button.HoverState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(156)))), ((int)(((byte)(189)))));
            this.suppliers_button.Location = new System.Drawing.Point(8, 319);
            this.suppliers_button.Margin = new System.Windows.Forms.Padding(2);
            this.suppliers_button.Name = "suppliers_button";
            this.suppliers_button.ShadowDecoration.BorderRadius = 10;
            this.suppliers_button.ShadowDecoration.Color = System.Drawing.Color.DarkGray;
            this.suppliers_button.ShadowDecoration.Shadow = new System.Windows.Forms.Padding(0, 0, 10, 10);
            this.suppliers_button.Size = new System.Drawing.Size(86, 86);
            this.suppliers_button.TabIndex = 5;
            this.suppliers_button.Text = "Suppliers";
            this.suppliers_button.TextOffset = new System.Drawing.Point(0, 20);
            this.suppliers_button.UseTransparentBackground = true;
            this.suppliers_button.CheckedChanged += new System.EventHandler(this.button_CheckedChanged);
            this.suppliers_button.Click += new System.EventHandler(this.suppliers_button_Click);
            // 
            // vehicles_button
            // 
            this.vehicles_button.Animated = true;
            this.vehicles_button.BackColor = System.Drawing.Color.Transparent;
            this.vehicles_button.BorderRadius = 23;
            this.vehicles_button.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.RadioButton;
            this.vehicles_button.CheckedState.FillColor = System.Drawing.Color.White;
            this.vehicles_button.CustomImages.HoveredImage = global::Phần_mềm_quản_lí_thuê_xe_ver2.Properties.Resources.phuong_tien_hover;
            this.vehicles_button.CustomImages.Image = global::Phần_mềm_quản_lí_thuê_xe_ver2.Properties.Resources.phuong_tien;
            this.vehicles_button.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.vehicles_button.CustomImages.ImageOffset = new System.Drawing.Point(0, -10);
            this.vehicles_button.CustomImages.ImageSize = new System.Drawing.Size(31, 31);
            this.vehicles_button.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.vehicles_button.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.vehicles_button.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.vehicles_button.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.vehicles_button.FillColor = System.Drawing.Color.Transparent;
            this.vehicles_button.Font = new System.Drawing.Font("Segoe UI", 7F);
            this.vehicles_button.ForeColor = System.Drawing.Color.Transparent;
            this.vehicles_button.HoverState.FillColor = System.Drawing.Color.Transparent;
            this.vehicles_button.HoverState.Font = new System.Drawing.Font("Segoe UI", 7F, System.Drawing.FontStyle.Bold);
            this.vehicles_button.HoverState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(156)))), ((int)(((byte)(189)))));
            this.vehicles_button.Location = new System.Drawing.Point(8, 219);
            this.vehicles_button.Margin = new System.Windows.Forms.Padding(2);
            this.vehicles_button.Name = "vehicles_button";
            this.vehicles_button.ShadowDecoration.BorderRadius = 10;
            this.vehicles_button.ShadowDecoration.Color = System.Drawing.Color.DarkGray;
            this.vehicles_button.ShadowDecoration.Shadow = new System.Windows.Forms.Padding(0, 0, 10, 10);
            this.vehicles_button.Size = new System.Drawing.Size(86, 86);
            this.vehicles_button.TabIndex = 5;
            this.vehicles_button.Text = "Vehicles";
            this.vehicles_button.TextOffset = new System.Drawing.Point(0, 20);
            this.vehicles_button.UseTransparentBackground = true;
            this.vehicles_button.CheckedChanged += new System.EventHandler(this.button_CheckedChanged);
            this.vehicles_button.Click += new System.EventHandler(this.vehicles_button_Click);
            // 
            // main_center
            // 
            this.main_center.Dock = System.Windows.Forms.DockStyle.Fill;
            this.main_center.Location = new System.Drawing.Point(115, 3);
            this.main_center.Name = "main_center";
            this.main_center.Size = new System.Drawing.Size(1425, 866);
            this.main_center.TabIndex = 3;
            // 
            // palette_dash_board
            // 
            this.palette_dash_board.ButtonSpecs.FormClose.Image = global::Phần_mềm_quản_lí_thuê_xe_ver2.Properties.Resources.close1;
            this.palette_dash_board.ButtonSpecs.FormClose.ImageStates.ImagePressed = global::Phần_mềm_quản_lí_thuê_xe_ver2.Properties.Resources.close2;
            this.palette_dash_board.ButtonSpecs.FormClose.ImageStates.ImageTracking = global::Phần_mềm_quản_lí_thuê_xe_ver2.Properties.Resources.close2;
            this.palette_dash_board.ButtonSpecs.FormMax.Image = global::Phần_mềm_quản_lí_thuê_xe_ver2.Properties.Resources.max1;
            this.palette_dash_board.ButtonSpecs.FormMax.ImageStates.ImagePressed = global::Phần_mềm_quản_lí_thuê_xe_ver2.Properties.Resources.max2;
            this.palette_dash_board.ButtonSpecs.FormMax.ImageStates.ImageTracking = global::Phần_mềm_quản_lí_thuê_xe_ver2.Properties.Resources.max2;
            this.palette_dash_board.ButtonSpecs.FormMin.Image = global::Phần_mềm_quản_lí_thuê_xe_ver2.Properties.Resources.mini1;
            this.palette_dash_board.ButtonSpecs.FormMin.ImageStates.ImagePressed = global::Phần_mềm_quản_lí_thuê_xe_ver2.Properties.Resources.mini2;
            this.palette_dash_board.ButtonSpecs.FormMin.ImageStates.ImageTracking = global::Phần_mềm_quản_lí_thuê_xe_ver2.Properties.Resources.mini2;
            this.palette_dash_board.ButtonStyles.ButtonForm.StateNormal.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(254)))), ((int)(((byte)(254)))));
            this.palette_dash_board.ButtonStyles.ButtonForm.StateNormal.Back.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(254)))), ((int)(((byte)(254)))));
            this.palette_dash_board.ButtonStyles.ButtonForm.StateNormal.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.palette_dash_board.ButtonStyles.ButtonForm.StateNormal.Border.Width = 0;
            this.palette_dash_board.ButtonStyles.ButtonForm.StatePressed.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(254)))), ((int)(((byte)(254)))));
            this.palette_dash_board.ButtonStyles.ButtonForm.StatePressed.Back.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(254)))), ((int)(((byte)(254)))));
            this.palette_dash_board.ButtonStyles.ButtonForm.StatePressed.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.palette_dash_board.ButtonStyles.ButtonForm.StatePressed.Border.Width = 0;
            this.palette_dash_board.ButtonStyles.ButtonForm.StateTracking.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(254)))), ((int)(((byte)(254)))));
            this.palette_dash_board.ButtonStyles.ButtonForm.StateTracking.Back.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(254)))), ((int)(((byte)(254)))));
            this.palette_dash_board.ButtonStyles.ButtonForm.StateTracking.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.palette_dash_board.ButtonStyles.ButtonForm.StateTracking.Border.Width = 0;
            this.palette_dash_board.ButtonStyles.ButtonFormClose.StateNormal.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(254)))), ((int)(((byte)(254)))));
            this.palette_dash_board.ButtonStyles.ButtonFormClose.StateNormal.Back.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(254)))), ((int)(((byte)(254)))));
            this.palette_dash_board.ButtonStyles.ButtonFormClose.StateNormal.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.palette_dash_board.ButtonStyles.ButtonFormClose.StateNormal.Border.Width = 0;
            this.palette_dash_board.ButtonStyles.ButtonFormClose.StatePressed.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(254)))), ((int)(((byte)(254)))));
            this.palette_dash_board.ButtonStyles.ButtonFormClose.StatePressed.Back.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(254)))), ((int)(((byte)(254)))));
            this.palette_dash_board.ButtonStyles.ButtonFormClose.StatePressed.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.palette_dash_board.ButtonStyles.ButtonFormClose.StatePressed.Border.Width = 0;
            this.palette_dash_board.ButtonStyles.ButtonFormClose.StateTracking.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(254)))), ((int)(((byte)(254)))));
            this.palette_dash_board.ButtonStyles.ButtonFormClose.StateTracking.Back.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(254)))), ((int)(((byte)(254)))));
            this.palette_dash_board.ButtonStyles.ButtonFormClose.StateTracking.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.palette_dash_board.ButtonStyles.ButtonFormClose.StateTracking.Border.Width = 0;
            this.palette_dash_board.FormStyles.FormMain.StateCommon.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(254)))), ((int)(((byte)(254)))));
            this.palette_dash_board.FormStyles.FormMain.StateCommon.Back.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(254)))), ((int)(((byte)(254)))));
            this.palette_dash_board.HeaderStyles.HeaderForm.StateCommon.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(254)))), ((int)(((byte)(254)))));
            this.palette_dash_board.HeaderStyles.HeaderForm.StateCommon.Back.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(254)))), ((int)(((byte)(254)))));
            this.palette_dash_board.HeaderStyles.HeaderForm.StateCommon.ButtonEdgeInset = 10;
            // 
            // dash_board
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(120F, 120F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1543, 872);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "dash_board";
            this.Palette = this.palette_dash_board;
            this.PaletteMode = ComponentFactory.Krypton.Toolkit.PaletteMode.Custom;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.StateActive.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.StateActive.Border.Rounding = 12;
            this.StateCommon.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.StateCommon.Border.Rounding = 12;
            this.StateInactive.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.StateInactive.Border.Rounding = 12;
            this.Text = "dash_board";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.dash_board_FormClosed);
            this.Load += new System.EventHandler(this.dash_board_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.guna2Panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.imgslide)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private ComponentFactory.Krypton.Toolkit.KryptonPalette palette_dash_board;
        private Guna.UI2.WinForms.Guna2Button customers_button;
        private Guna.UI2.WinForms.Guna2Button vehicles_button;
        private Guna.UI2.WinForms.Guna2Button suppliers_button;
        private Guna.UI2.WinForms.Guna2Button home_button;
        private Guna.UI2.WinForms.Guna2Button employee_button;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Button button1;
        private Guna.UI2.WinForms.Guna2PictureBox imgslide;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel3;
        private Guna.UI2.WinForms.Guna2Button reports_button;
        private Guna.UI2.WinForms.Guna2CustomGradientPanel main_center;
    }
}